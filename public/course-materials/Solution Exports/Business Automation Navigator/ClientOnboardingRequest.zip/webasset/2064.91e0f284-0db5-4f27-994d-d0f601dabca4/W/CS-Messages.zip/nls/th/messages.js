/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "คลาส",

		// Property list
		properties_file_name: "ชื่อไฟล์",
		properties_file_save_in: "บันทึกใน",
		properties_add_file: "เพิ่มไฟล์",
		properties_add_mvcp: "เพิ่ม ${0}",
		properties_remove_mvcp: "ลบออกจาก ${0}",
		properties_use_file_name: "จะใช้ชื่อไฟล์สำหรับคุณสมบัตินี้",

		properties_optional_label: "${0} (ทางเลือก)",

		properties_document_or_folder_not_found: "ไม่พบเอกสารหรือโฟลเดอร์",
		properties_class_not_found: "ไม่พบคลาสเนื้อหา",
		properties_folder_duplicate_item_invalid_prop: "ไอเท็มที่มีชื่อเดียวกันมีอยู่แล้วในโฟลเดอร์ หรือคุณป้อนค่าคุณสมบัติไม่ถูกต้อง",
		properties_item_invalid_prop: "คุณป้อนค่าที่ไม่ถูกต้องสำหรับคุณสมบัติหนึ่งรายการหรือมากกว่า",

		properties_invalid_long_value: "ค่านี้ไม่ถูกต้อง ค่าต้องเป็นจำนวนเต็ม เช่น 5 หรือ 1349",
		properties_invalid_float_value: "ค่าไม่ถูกต้อง ค่าต้องเป็นจำนวน floating point เช่น 1.2 หรือ 365",
		properties_min_value: "ค่าต่ำสุด: ${0}",
		properties_max_value: "ค่าสูงสุด: ${0}",
		properties_max_length: "ความยาวสูงสุด: ${0}",
		properties_invalid_guid: "ค่าไม่ถูกต้อง ค่าต้องเป็น Globally Unique Identifier (GUID) เช่น {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}",
		properties_value_required: "จำเป็นต้องมีค่านี้",
		properties_unique_value_required: "ค่านี้ต้องไม่ซ้ำ",
		properties_file_required: "ต้องการไฟล์",
		properties_invalid_folder_name: "ชื่อโฟลเดอร์ไม่สามารถมีอักขระใด ๆ ต่อไปนี้: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "คุณกำลังเปลี่ยนแปลงคุณสมบัติของเอกสารต่อไปนี้<br>${0}<br><br>คุณต้องการบันทึกการเปลี่ยนแปลงของคุณหรือไม่?",
		properties_move_edit_confirm_no: "ไม่",
		properties_move_edit_confirm_yes: "ใช่",
		properties_move_edit_confirm_title: "การยืนยัน",
		properties_edit_save_success: "บันทึกคุณสมบัติแล้ว",
		properties_edit_save_failure: "คุณสมบัติยังไม่ถูกบันทึก",
		properties_no_item_selected: "ไม่ได้เลือกไอเท็ม",

		// Content list
		contlist_column_spec_title: "ชื่อเรื่อง",
		contlist_column_spec_name: "ชื่อ",
		contlist_column_spec_version_label: "เวอร์ชัน",
		contlist_column_spec_modified_by: "ปรับเปลี่ยนโดย",
		contlist_column_spec_mod_date: "ปรับเปลี่ยนล่าสุด",
		contlist_column_spec_created_by: "สร้างโดย",
		contlist_column_spec_creation_date: "สร้าง",
		contlist_column_spec_mime_type: "ชนิดเอกสาร",
		contlist_column_spec_size: "ขนาด",
		contlist_column_spec_thumbnail: "ตัวอย่าง",

		contlist_paging_no_more_items: "ไม่มีไอเท็ม",
		contlist_paging_of_at_least_items: "${0} จากอย่างน้อย ${1} ไอเท็ม",
		contlist_paging_of_items: "${0} จาก ${1} ไอเท็ม",
		contlist_paging_items: "ไอเท็ม ${0}",
		contlist_paging_items_per_page: "ไอเท็มต่อเพจ: ${0}",

		contlist_checked_out: "เช็กเอาต์",
		contlist_checked_out_by: "เช็กเอาต์โดย ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "ไม่ได้ระบุเซิร์ฟเวอร์",
		contlist_invalid_server_error: "เซิร์ฟเวอร์ '{0}' ไม่มีอยู่",
		contlist_error_retrieving_doc_props: "ข้อผิดพลาดในการเรียกค้นคุณสมบัติเอกสาร",
		contlist_error_retrieving_folder_props: "ข้อผิดพลาดในการเรียกค้นคุณสมบัติโฟลเดอร์",
		contlist_checkout_failed: "ไม่สามารถเช็กเอาต์เอกสาร",
		contlist_cancel_checkout_failed: "ยกเลิกการเช็กเอาต์ล้มเหลว",
		contlist_rename_folder_failed: "ไม่สามารถเปลี่ยนชื่อไฟล์",
		contlist_folder_name_not_unique: "ชื่อโฟลเดอร์ต้องไม่ซ้ำ",
		contlist_delete_object_failed: "ไม่สามารถลบอ็อบเจ็กต์",
		contlist_display_properties_failed: "ไม่สามารถแสดงผลคุณสมบัติ ${0}",
		contlist_save_props_failed: "ไม่สามารถบันทึกคุณสมบัติ",
		contlist_upload_failed: "ไม่สามารถอัพโหลดเวอร์ชัน",
		contlist_add_folder_failed: "ไม่สามารถเพิ่มโฟลเดอร์ ${0}",
		contlist_add_document_failed: "ไม่สามารถเพิ่มเอกสาร ${0}",
		contlist_search_failed: "ไม่สามารถเรียกค้นผลการค้นหา",
		contlist_folder_containees_failed: "ไม่สามารถเรียกค้นเนื้อหาโฟลเดอร์",
		contlist_delete_folder_referenced: "ไม่สามารถลบโฟลเดอร์เนื่องจากยังมีโหลดเดอร์ย่อยอยู่",
		contlist_docs_not_added: "ไม่สามารถเพิ่มเอกสารต่อไปนี้: ${0}",

		contlist_checkout_success: "เอกสารถูกเช็กเอาต์แล้ว",
		contlist_delete_success: "อ็อบเจ็กต์ถูกลบแล้ว",
		contlist_rename_folder_success: "โฟลเดอร์ถูกเปลี่ยนชื่อแล้ว",
		contlist_save_props_success: "คุณสมบัติถูกบันทึกแล้ว",
		contlist_cancel_checkout_success: "ยกเลิกการเช็กเอาต์เรียบร้อยแล้ว",
		contlist_upload_version_success: "เวอร์ชันถูกอัพโหลดแล้ว",
		contlist_add_folder_success: "โฟลเดอร์ถูกเพิ่มแล้ว",
		contlist_add_doc_success: "เอกสารถูกเพิ่มแล้ว",
		contlist_add_docs_success: "เอกสารถูกเพิ่มแล้ว",

		contlist_menu_action_open: "เปิด",
		contlist_menu_action_rename: "เปลี่ยนชื่อ",
		contlist_menu_action_properties: "คุณสมบัติ",
		contlist_menu_action_view: "ดู",
		contlist_menu_action_download: "ดาวน์โหลด",
		contlist_menu_action_checkout: "เช็กเอาต์",
		contlist_menu_action_edit_document: "แก้ไขเอกสาร",
		contlist_menu_action_cancel_checkout: "ยกเลิกการเช็กเอาต์",
		contlist_menu_action_delete_doc: "ลบเอกสาร",
		contlist_menu_action_rename_folder: "เปลี่ยนชื่อโฟลเดอร์",
		contlist_menu_action_add_folder: "เพิ่มโฟลเดอร์",
		contlist_menu_action_delete_folder: "ลบโฟลเดอร์",
		contlist_menu_action_add_doc: "เพิ่มเอกสาร",
		contlist_menu_action_upload: "อัพโหลดอัพโหลดใหม่",

		contlist_document_properties: "คุณสมบัติเอกสาร",
		contlist_folder_properties: "คุณสมบัติโฟลเดอร์",
		contlist_folder_name: "ชื่อโฟลเดอร์",

		contlist_cancel_btn_label: "ยกเลิก",
		contlist_add_btn_label: "เพิ่ม",
		contlist_ok_btn_label: "ตกลง",
		contlist_edit_btn_label: "แก้ไข",
		contlist_save_btn_label: "บันทึก",
		contlist_upload_btn_label: "อัพโหลด",
		contlist_refresh_btn_label: "รีเฟรช",
		contlist_next_btn_label: "ถัดไป",
		contlist_previous_btn_label: "ก่อนหน้า",

		contlist_delete_folder_confirm: "คุณกำลังจะลบโฟลเดอร์ ${0} คุณต้องการทำต่อหรือไม่?",
		contlist_delete_doc_confirm: "คุณกำลังจะลบเอกสาร ${0} คุณต้องการทำต่อหรือไม่?",

		contlist_no_mimetype: "ไอเท็มนี้ไม่มีเนื้อหา",
		contlist_folder_mimetype: "โฟลเดอร์",

		contlist_filter_search_hint: "ค้นหาเอกสาร",
		contlist_filter_folder_hint: "รายการตัวกรอง",

		contlist_root_folder: "โฟลเดอร์รูท",
		contlist_drop_folder_error: "คุณไม่สามารถเพิ่มโฟลเดอร์ได้ ให้เลือกเฉพาะไฟล์",
		contlist_add_in_process: "โปรดรอจนกว่าการเพิ่มเอกสารก่อนหน้านี้เสร็จสมบูรณ์ ก่อนที่จะเพิ่มเอกสารอื่น",
		contlist_add_doc_max_exceeded: "คุณสามารถเพิ่มได้สูงสุด ${0} ไอเท็มต่อครั้ง คุณกำลังพยายามเพิ่ม ${1} ไอเท็ม",
		contlist_progress_success: "สำเร็จ",
		contlist_progress_alert: "การเตือน",
		contlist_progress_error: "ข้อผิดพลาด",
		contlist_progress_uploading: "กำลังอัพโหลด",
		contlist_progress_processing: "กำลังประมวลผล 1 ไฟล์",
		contlist_progress_uploading_text: "กำลังอัพโหลด 1 ไฟล์",
		contlist_progress_upload_failed: "เกิดปัญหาขึ้น",
		contlist_progress_close: "ปิด",
		progress_ind_uploaded_status: "อัพโหลดแล้ว",
		progress_ind_uploaded: "อัพโหลดแล้ว 1 ไฟล์",
		progress_ind_uploaded_error: "การประมวลผลยังไม่เริ่มต้น",		
		progress_ind_processing_status: "กำลังประมวลผล",
		progress_ind_processing_err: "เกิดปัญหาขึ้น",
		progress_ind_processed: "ประมวลผลแล้ว 1 ไฟล์",	
		progress_ind_failed: "ล้มเหลว",
		progress_ind_review_doc: "จำเป็นต้องตรวจทาน",	
		progress_ind_updating: "กำลังอัพเดต 1 ไฟล์",
		progress_ind_updating_status: "กำลังอัพเดต",
		progress_ind_update_err: "เกิดปัญหาขึ้น",
		progress_ind_timeout: "การมอนิเตอร์หมดเวลา",
		progress_ind_refresh: "รีเฟรช",

		getcontent_ret_versions_error: "ชุดเวอร์ชันที่เรียกค้นล้มเหลว",
		getcontent_ret_properties_error: "คุณสมบัติเอกสารที่เรียกค้นล้มเหลว",

		contentviewer_test_mode: "วิวเวอร์จะไม่แสดงเอกสารในโหมดแสดงตัวอย่าง คุณต้องรันในแอ็พพลิเคชันเดสก์ท็อปของ IBM Navigator",

		thumbnail_retreival_error: "อิมเมจขนาดเล็กที่กำลังเรียกค้นล้มเหลว",

		status_10: "อัพโหลดแล้ว",
		status_20: "กำลังประมวลผล",
		status_25: "กำลังประมวลผลใหม่",
		status_30: "จำเป็นต้องตรวจทาน",
		status_40: "กำลังอัพเดต",
		status_900: "ข้อผิดพลาดในการประมวลผล",
		status_910: "ข้อผิดพลาดในการอัพเดต",

		/*do not remove this line*/nop: null
});
