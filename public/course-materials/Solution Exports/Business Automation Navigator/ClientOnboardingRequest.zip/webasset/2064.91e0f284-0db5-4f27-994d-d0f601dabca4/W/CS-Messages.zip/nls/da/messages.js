/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Klasse",

		// Property list
		properties_file_name: "Filnavn",
		properties_file_save_in: "Gem i",
		properties_add_file: "Tilføj fil",
		properties_add_mvcp: "Tilføj ${0}",
		properties_remove_mvcp: "Fjern fra ${0}",
		properties_use_file_name: "Filnavnet bruges til denne egenskab",

		properties_optional_label: "${0} (valgfrit)",

		properties_document_or_folder_not_found: "Det ønskede dokument eller folderen findes ikke.",
		properties_class_not_found: "Indholdsklassen findes ikke.",
		properties_folder_duplicate_item_invalid_prop: "Der findes allerede et element med det samme navn i folderen, eller også har du angivet en ugyldig egenskabsværdi.",
		properties_item_invalid_prop: "Du har angivet en ugyldig værdi for en eller flere egenskaber.",

		properties_invalid_long_value: "Værdien er ugyldig. Værdien skal være et heltal, f.eks. 5 eller 1349.",
		properties_invalid_float_value: "Værdien er ikke gyldig. Værdien skal være et tal med flydende decimaltegn, f.eks. 1,2 eller 365.",
		properties_min_value: "Minimumsværdi: ${0}",
		properties_max_value: "Maksimumsværdi: ${0}",
		properties_max_length: "Maksimumslængde: ${0}",
		properties_invalid_guid: "Værdien er ikke gyldig. Værdien skal være en GUID (Globally Unique Identifier), f.eks. {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Værdien er påkrævet.",
		properties_unique_value_required: "Værdien skal være entydig.",
		properties_file_required: "Du skal angive en fil.",
		properties_invalid_folder_name: "Et foldernavn må ikke indeholde følgende tegn: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Du ændrer egenskaberne for følgende dokument:<br>${0}<br><br>Vil du gemme ændringerne?",
		properties_move_edit_confirm_no: "Nej",
		properties_move_edit_confirm_yes: "Ja",
		properties_move_edit_confirm_title: "Bekræftelse",
		properties_edit_save_success: "Egenskaber gemt",
		properties_edit_save_failure: "Egenskaberne blev ikke gemt",
		properties_no_item_selected: "Ingen markerede elementer.",

		// Content list
		contlist_column_spec_title: "Titel",
		contlist_column_spec_name: "Navn",
		contlist_column_spec_version_label: "Version",
		contlist_column_spec_modified_by: "Ændret af",
		contlist_column_spec_mod_date: "Sidst ændret",
		contlist_column_spec_created_by: "Oprettet af",
		contlist_column_spec_creation_date: "Oprettet",
		contlist_column_spec_mime_type: "Dokumenttype",
		contlist_column_spec_size: "Størrelse",
		contlist_column_spec_thumbnail: "Miniature",

		contlist_paging_no_more_items: "Der er ikke flere elementer",
		contlist_paging_of_at_least_items: "${0} af mindst ${1} elementer",
		contlist_paging_of_items: "${0} af ${1} elementer",
		contlist_paging_items: "Elementer ${0}",
		contlist_paging_items_per_page: "Elementer pr. side: ${0}",

		contlist_checked_out: "Tjekket ud",
		contlist_checked_out_by: "Tjekket ud af ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Der er ikke angivet en server.",
		contlist_invalid_server_error: "Serveren '{0}' findes ikke.",
		contlist_error_retrieving_doc_props: "Der er opstået en fejl under hentning af dokumentegenskaber.",
		contlist_error_retrieving_folder_props: "Der er opstået en fejl under hentning af folderegenskaber.",
		contlist_checkout_failed: "Dokumentet kan ikke tjekkes ud",
		contlist_cancel_checkout_failed: "Annullér udtjekning ikke udført",
		contlist_rename_folder_failed: "Kan ikke omdøbe folderen.",
		contlist_folder_name_not_unique: "Foldernavnet skal være entydigt.",
		contlist_delete_object_failed: "Objektet kan ikke slettes.",
		contlist_display_properties_failed: "Egenskaberne kan ikke vises. ${0}",
		contlist_save_props_failed: "Egenskaberne kan ikke gemmes.",
		contlist_upload_failed: "Versionen kan ikke uploades",
		contlist_add_folder_failed: "Folderen kan ikke tilføjes. ${0}",
		contlist_add_document_failed: "Dokumentet kan ikke tilføjes. ${0}",
		contlist_search_failed: "Søgeresultaterne kan ikke hentes.",
		contlist_folder_containees_failed: "Folderindholdet kan ikke hentes.",
		contlist_delete_folder_referenced: "Folderen kan ikke slettes, fordi den indeholder underfoldere.",
		contlist_docs_not_added: "Følgende dokumenter kunne ikke tilføjes: ${0}",

		contlist_checkout_success: "Dokumentet er tjekket ud",
		contlist_delete_success: "Objektet er slettet",
		contlist_rename_folder_success: "Folderen er omdøbt",
		contlist_save_props_success: "Egenskaberne er gemt",
		contlist_cancel_checkout_success: "Annullér udtjekning udført",
		contlist_upload_version_success: "Versionen er uploadet",
		contlist_add_folder_success: "Folderen er tilføjet",
		contlist_add_doc_success: "Dokumentet er tilføjet",
		contlist_add_docs_success: "Dokumenterne er tilføjet",

		contlist_menu_action_open: "Åbn",
		contlist_menu_action_rename: "Omdøb",
		contlist_menu_action_properties: "Egenskaber",
		contlist_menu_action_view: "Vis",
		contlist_menu_action_download: "Download",
		contlist_menu_action_checkout: "Tjek ud",
		contlist_menu_action_edit_document: "Redigér dokument",
		contlist_menu_action_cancel_checkout: "Annullér udtjekning",
		contlist_menu_action_delete_doc: "Slet dokument",
		contlist_menu_action_rename_folder: "Omdøb folder",
		contlist_menu_action_add_folder: "Tilføj folder",
		contlist_menu_action_delete_folder: "Slet folder",
		contlist_menu_action_add_doc: "Tilføj dokument",
		contlist_menu_action_upload: "Upload ny version",

		contlist_document_properties: "Dokumentegenskaber",
		contlist_folder_properties: "Folderegenskaber",
		contlist_folder_name: "Foldernavn",

		contlist_cancel_btn_label: "Annullér",
		contlist_add_btn_label: "Tilføj",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Redigér",
		contlist_save_btn_label: "Gem",
		contlist_upload_btn_label: "Upload",
		contlist_refresh_btn_label: "Opfrisk",
		contlist_next_btn_label: "Næste",
		contlist_previous_btn_label: "Forrige",

		contlist_delete_folder_confirm: "Du er ved at slette folderen ${0}. Vil du fortsætte?",
		contlist_delete_doc_confirm: "Du er ved at slette dokumentet ${0}. Vil du fortsætte?",

		contlist_no_mimetype: "Dette element er tomt.",
		contlist_folder_mimetype: "Folder",

		contlist_filter_search_hint: "Søg efter dokumenter",
		contlist_filter_folder_hint: "Filtrér liste",

		contlist_root_folder: "Rodfolder",
		contlist_drop_folder_error: "Du kan ikke tilføje foldere. Vælg kun filer.",
		contlist_add_in_process: "Vent, til det forrige dokument er tilføjet, før du tilføjer et nyt.",
		contlist_add_doc_max_exceeded: "Du kan tilføje op til ${0} elementer ad gangen. Du forsøger at tilføje ${1} elementer.",
		contlist_progress_success: "Udført",
		contlist_progress_alert: "Advarsel",
		contlist_progress_error: "Fejl",
		contlist_progress_uploading: "Uploader",
		contlist_progress_processing: "Behandler 1 fil",
		contlist_progress_uploading_text: "Uploader 1 fil",
		contlist_progress_upload_failed: "Der er opstået et problem",
		contlist_progress_close: "Luk",
		progress_ind_uploaded_status: "Uploadet",
		progress_ind_uploaded: "1 fil blev uploadet",
		progress_ind_uploaded_error: "Behandlingen startede ikke",		
		progress_ind_processing_status: "Behandler",
		progress_ind_processing_err: "Der er opstået et problem",
		progress_ind_processed: "1 fil blev behandlet",	
		progress_ind_failed: "Ikke udført",
		progress_ind_review_doc: "Gennemgang er påkrævet",	
		progress_ind_updating: "Opdaterer 1 fil",
		progress_ind_updating_status: "Opdaterer",
		progress_ind_update_err: "Der er opstået et problem",
		progress_ind_timeout: "Tidsfristen for overvågning er overskredet",
		progress_ind_refresh: "Opfrisk",

		getcontent_ret_versions_error: "Versionsserien kunne ikke hentes",
		getcontent_ret_properties_error: "Dokumentegenskaberne kunne ikke hentes",

		contentviewer_test_mode: "Fremviseren viser ikke dokumenter i eksempeltilstand. Du skal anvende en IBM Navigator-arbejdspladsapplikation.",

		thumbnail_retreival_error: "Miniaturen kunne ikke hentes.",

		status_10: "Uploadet",
		status_20: "Behandler",
		status_25: "Behandler igen",
		status_30: "Gennemgang er påkrævet",
		status_40: "Opdaterer",
		status_900: "Fejl under behandling",
		status_910: "Fejl under opdatering",

		/*do not remove this line*/nop: null
});
