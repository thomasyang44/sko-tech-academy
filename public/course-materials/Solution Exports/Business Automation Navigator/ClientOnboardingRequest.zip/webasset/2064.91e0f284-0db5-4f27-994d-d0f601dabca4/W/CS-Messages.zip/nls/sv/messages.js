/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Klass",

		// Property list
		properties_file_name: "Filnamn",
		properties_file_save_in: "Spara i",
		properties_add_file: "Lägg till fil",
		properties_add_mvcp: "Lägg till ${0}",
		properties_remove_mvcp: "Ta bort från ${0}",
		properties_use_file_name: "Filnamnet används för den här egenskapen",

		properties_optional_label: "${0} (valfritt)",

		properties_document_or_folder_not_found: "Dokumentet eller mappen kan inte hittas.",
		properties_class_not_found: "Innehållsklassen kan inte hittas.",
		properties_folder_duplicate_item_invalid_prop: "Det finns redan ett objekt med det namnet i mappen, eller så angav du ett ogiltigt egenskapsvärde.",
		properties_item_invalid_prop: "Du angav ett ogiltigt värde för en eller flera egenskaper.",

		properties_invalid_long_value: "Det här värdet är ogiltigt. Värdet måste vara ett heltal. Exempel: 5 eller 1349.",
		properties_invalid_float_value: "Värdet är ogiltigt. Värdet måste vara ett flyttal. Exempel: 1.2 eller 365.",
		properties_min_value: "Minimivärde: ${0}",
		properties_max_value: "Maxvärde: ${0}",
		properties_max_length: "Maxlängd: ${0}",
		properties_invalid_guid: "Värdet är ogiltigt. Värdet måste vara ett GUID (Globally Unique Identifier). Exempel: {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Värdet är obligatoriskt.",
		properties_unique_value_required: "Värdet måste vara unikt.",
		properties_file_required: "En fil krävs.",
		properties_invalid_folder_name: "Mappnamnet får inte innehålla något av följande tecken: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Du ändrar egenskaperna för följande dokument<br>${0}<br><br>Vill du spara ändringarna?",
		properties_move_edit_confirm_no: "Nej",
		properties_move_edit_confirm_yes: "Ja",
		properties_move_edit_confirm_title: "Bekräftelse",
		properties_edit_save_success: "Egenskaper sparades",
		properties_edit_save_failure: "Egenskaperna sparades inte",
		properties_no_item_selected: "Inget objekt är valt.",

		// Content list
		contlist_column_spec_title: "Namn",
		contlist_column_spec_name: "Namn",
		contlist_column_spec_version_label: "Version",
		contlist_column_spec_modified_by: "Ändrades av",
		contlist_column_spec_mod_date: "Senast ändrat",
		contlist_column_spec_created_by: "Skapades av",
		contlist_column_spec_creation_date: "Skapades",
		contlist_column_spec_mime_type: "Dokumenttyp",
		contlist_column_spec_size: "Storlek",
		contlist_column_spec_thumbnail: "Miniatyrbild",

		contlist_paging_no_more_items: "Det finns inga fler objekt",
		contlist_paging_of_at_least_items: "${0} av minst ${1} objekt",
		contlist_paging_of_items: "${0} av ${1} objekt",
		contlist_paging_items: "Objekt ${0}",
		contlist_paging_items_per_page: "Objekt per sida: ${0}",

		contlist_checked_out: "Checkades ut",
		contlist_checked_out_by: "Checkades ut av ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "En server angavs inte.",
		contlist_invalid_server_error: "Servern {0} finns inte.",
		contlist_error_retrieving_doc_props: "Fel vid hämtning av dokumentegenskaper.",
		contlist_error_retrieving_folder_props: "Fel vid hämtning av mappegenskaper.",
		contlist_checkout_failed: "Dokumentet kunde inte checkas ut",
		contlist_cancel_checkout_failed: "Det gick inte att avbryta utcheckning",
		contlist_rename_folder_failed: "Det gick inte att byta namn på mappen.",
		contlist_folder_name_not_unique: "Mappnamnet måste vara unikt.",
		contlist_delete_object_failed: "Det gick inte att ta bort objektet.",
		contlist_display_properties_failed: "Egenskaperna kunde inte visas. ${0}",
		contlist_save_props_failed: "Egenskaperna kunde inte sparas",
		contlist_upload_failed: "Versionen kunde inte överföras",
		contlist_add_folder_failed: "Mappen kunde inte läggas till. ${0}",
		contlist_add_document_failed: "Dokumentet kunde inte läggas till. ${0}",
		contlist_search_failed: "Sökresultaten kunde inte hämtas",
		contlist_folder_containees_failed: "Mappinnehållet kunde inte hämtas",
		contlist_delete_folder_referenced: "Mappen kan inte tas bort eftersom den innehåller undermappar.",
		contlist_docs_not_added: "Det gick inte att lägga till följande dokument: ${0}",

		contlist_checkout_success: "Dokumentet har checkats ut",
		contlist_delete_success: "Objektet har tagits bort",
		contlist_rename_folder_success: "Mappnamnet har bytts",
		contlist_save_props_success: "Egenskaperna har sparats",
		contlist_cancel_checkout_success: "Utcheckning har avbrutits",
		contlist_upload_version_success: "Versionen har överförts",
		contlist_add_folder_success: "Mappen har lagts till",
		contlist_add_doc_success: "Dokumentet har lagts till",
		contlist_add_docs_success: "Dokumenten lades till",

		contlist_menu_action_open: "Öppna",
		contlist_menu_action_rename: "Byt namn",
		contlist_menu_action_properties: "Egenskaper",
		contlist_menu_action_view: "Visa",
		contlist_menu_action_download: "Hämta",
		contlist_menu_action_checkout: "Checka ut",
		contlist_menu_action_edit_document: "Redigera dokument",
		contlist_menu_action_cancel_checkout: "Avbryt utcheckning",
		contlist_menu_action_delete_doc: "Ta bort dokument",
		contlist_menu_action_rename_folder: "Byt namn på mapp",
		contlist_menu_action_add_folder: "Lägg till mapp",
		contlist_menu_action_delete_folder: "Ta bort mapp",
		contlist_menu_action_add_doc: "Lägg till dokument",
		contlist_menu_action_upload: "Överför ny version",

		contlist_document_properties: "Dokumentegenskaper",
		contlist_folder_properties: "Mappegenskaper",
		contlist_folder_name: "Mappnamn",

		contlist_cancel_btn_label: "Avbryt",
		contlist_add_btn_label: "Lägg till",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Redigera",
		contlist_save_btn_label: "Spara",
		contlist_upload_btn_label: "Överför",
		contlist_refresh_btn_label: "Uppdatera",
		contlist_next_btn_label: "Nästa",
		contlist_previous_btn_label: "Föregående",

		contlist_delete_folder_confirm: "Du är på väg att ta bort mappen ${0}. Vill du fortsätta?",
		contlist_delete_doc_confirm: "Du är på väg att ta bort dokumentet ${0}. Vill du fortsätta?",

		contlist_no_mimetype: "Objektet saknar innehåll.",
		contlist_folder_mimetype: "Mapp",

		contlist_filter_search_hint: "Sök dokument",
		contlist_filter_folder_hint: "Filterlista",

		contlist_root_folder: "Rotmapp",
		contlist_drop_folder_error: "Du kan inte lägga till mappar. Välj endast filer.",
		contlist_add_in_process: "Vänta tills det föregående dokumentet lagts till innan du lägger till ett nytt dokument.",
		contlist_add_doc_max_exceeded: "Du kan lägga till ${0} objekt åt gången. Du försöker lägga till ${1} objekt.",
		contlist_progress_success: "Lyckades",
		contlist_progress_alert: "Varning",
		contlist_progress_error: "Fel",
		contlist_progress_uploading: "Överför",
		contlist_progress_processing: "Bearbetar 1 fil",
		contlist_progress_uploading_text: "Överför 1 fil",
		contlist_progress_upload_failed: "Problem inträffade",
		contlist_progress_close: "Stäng",
		progress_ind_uploaded_status: "Överfört",
		progress_ind_uploaded: "Överför 1 fil",
		progress_ind_uploaded_error: "Bearbetningen startade inte",		
		progress_ind_processing_status: "Bearbetar",
		progress_ind_processing_err: "Problem inträffade",
		progress_ind_processed: "Bearbetade 1 fil",	
		progress_ind_failed: "Fel",
		progress_ind_review_doc: "Granskning krävs",	
		progress_ind_updating: "Uppdaterar 1 fil",
		progress_ind_updating_status: "Uppdaterar",
		progress_ind_update_err: "Problem inträffade",
		progress_ind_timeout: "Tidsgräns för övervakning överskreds",
		progress_ind_refresh: "Uppdatera",

		getcontent_ret_versions_error: "Hämtning av versionsserier misslyckades",
		getcontent_ret_properties_error: "Det gick inte att hämta dokumentegenskaper",

		contentviewer_test_mode: "Visningsprogrammet visar inte dokument i förhandsgranskningsläge. Du måste köra i ett IBM Navigator-skrivbordsprogram.",

		thumbnail_retreival_error: "Det gick inte att hämta miniatyrbilden.",

		status_10: "Överfört",
		status_20: "Bearbetar",
		status_25: "Ombearbetar",
		status_30: "Granskning krävs",
		status_40: "Uppdaterar",
		status_900: "Bearbetningsfel",
		status_910: "Uppdateringsfel",

		/*do not remove this line*/nop: null
});
