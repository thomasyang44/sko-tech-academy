/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Classe",

		// Property list
		properties_file_name: "Nom del fitxer",
		properties_file_save_in: "Desa a",
		properties_add_file: "Afegeix fitxer",
		properties_add_mvcp: "Afegeix ${0}",
		properties_remove_mvcp: "Elimina de ${0}",
		properties_use_file_name: "El nom del fitxer es pot utilitzar per a aquesta propietat",

		properties_optional_label: "${0} (opcional)",

		properties_document_or_folder_not_found: "No es pot trobar el document o la carpeta.",
		properties_class_not_found: "No es pot trobar la classe de contingut.",
		properties_folder_duplicate_item_invalid_prop: "Ja existeix un element amb el mateix nom a la carpeta o heu especificat un valor de propietat no vàlid.",
		properties_item_invalid_prop: "Heu especificar un valor no vàlid per a una de les propietat o per a més d'una.",

		properties_invalid_long_value: "Aquest valor no és vàlid. El valor ha de ser un enter, per exemple 5 o 1349.",
		properties_invalid_float_value: "El valor no és vàlid. El valor ha de ser un número flotant, per exemple 1,2 o 365.",
		properties_min_value: "Valor mínim: ${0}",
		properties_max_value: "Valor màxim: ${0}",
		properties_max_length: "Longitud màxima: ${0}",
		properties_invalid_guid: "El valor no és vàlid. El valor ha de ser un GUID, per exemple, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Aquest valor és necessari.",
		properties_unique_value_required: "Aquest valor ha de ser exclusiu.",
		properties_file_required: "És obligatori indicar un fitxer.",
		properties_invalid_folder_name: "El nom de la carpeta no pot contenir cap dels caràcters següents: * \\ / : ? \" < > |",

		properties_move_edit_confirm_msg: "Esteu canviant les propietats del document següent<br>${0}<br><br>Voleu desar els canvis?",
		properties_move_edit_confirm_no: "No",
		properties_move_edit_confirm_yes: "Sí",
		properties_move_edit_confirm_title: "Confirmació",
		properties_edit_save_success: "Propietats desades",
		properties_edit_save_failure: "Les propietats no s'han desat",
		properties_no_item_selected: "No s'ha seleccionat cap element.",

		// Content list
		contlist_column_spec_title: "Títol",
		contlist_column_spec_name: "Nom",
		contlist_column_spec_version_label: "Versió",
		contlist_column_spec_modified_by: "Modificat per",
		contlist_column_spec_mod_date: "Darrera modificació",
		contlist_column_spec_created_by: "Creat per",
		contlist_column_spec_creation_date: "Creat el",
		contlist_column_spec_mime_type: "Tipus de document",
		contlist_column_spec_size: "Mida",
		contlist_column_spec_thumbnail: "Miniatura",

		contlist_paging_no_more_items: "No hi ha més elements",
		contlist_paging_of_at_least_items: "${0} de com a mínim ${1} elements",
		contlist_paging_of_items: "${0} de ${1} elements",
		contlist_paging_items: "Elements ${0}",
		contlist_paging_items_per_page: "Elements per pàgina: ${0}",

		contlist_checked_out: "Extret",
		contlist_checked_out_by: "Extret per ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "No s'ha especificat cap servidor.",
		contlist_invalid_server_error: "El servidor '{0}' no existeix.",
		contlist_error_retrieving_doc_props: "Error en recuperar les propietats del document.",
		contlist_error_retrieving_folder_props: "Error en recuperar les propietats de la carpeta.",
		contlist_checkout_failed: "No s'ha pogut extreure el document",
		contlist_cancel_checkout_failed: "Error en la cancel·lació de l'extracció",
		contlist_rename_folder_failed: "No s'ha pogut canviar el nom de la carpeta.",
		contlist_folder_name_not_unique: "El nom de la carpeta ha de ser únic.",
		contlist_delete_object_failed: "No s'ha pogut suprimir l'objecte.",
		contlist_display_properties_failed: "No s'han pogut visualitzar les propietats. ${0}",
		contlist_save_props_failed: "No s'han pogut desar les propietats",
		contlist_upload_failed: "No s'ha pogut carregar la versió",
		contlist_add_folder_failed: "No s'ha pogut afegir la carpeta. ${0}",
		contlist_add_document_failed: "No s'ha pogut afegir el document. ${0}",
		contlist_search_failed: "No s'han pogut recuperar els resultats de la cerca",
		contlist_folder_containees_failed: "No s'ha pogut recuperar el contingut de la carpeta",
		contlist_delete_folder_referenced: "No es pot suprimir la carpeta perquè conté subcarpetes.",
		contlist_docs_not_added: "No s'han pogut afegir els següents documents: ${0}",

		contlist_checkout_success: "S'ha extret el document",
		contlist_delete_success: "S'ha suprimir l'objecte",
		contlist_rename_folder_success: "S'ha canviat el nom de la carpeta",
		contlist_save_props_success: "S'han desat les propietats",
		contlist_cancel_checkout_success: "La cancel·lació de l'extracció ha estat correcta",
		contlist_upload_version_success: "S'ha carregat la versió",
		contlist_add_folder_success: "S'ha afegit la carpeta",
		contlist_add_doc_success: "S'ha afegit el document",
		contlist_add_docs_success: "S'han afegit els documents. ",

		contlist_menu_action_open: "Obre",
		contlist_menu_action_rename: "Canvia el nom",
		contlist_menu_action_properties: "Propietats",
		contlist_menu_action_view: "Visualització",
		contlist_menu_action_download: "Baixa",
		contlist_menu_action_checkout: "Extreu",
		contlist_menu_action_edit_document: "Edita el document",
		contlist_menu_action_cancel_checkout: "Cancel·la l'extracció",
		contlist_menu_action_delete_doc: "Suprimeix el document",
		contlist_menu_action_rename_folder: "Reanomena la carpeta",
		contlist_menu_action_add_folder: "Afegeix carpeta",
		contlist_menu_action_delete_folder: "Suprimeix la carpeta",
		contlist_menu_action_add_doc: "Afegeix un document",
		contlist_menu_action_upload: "Carrega versió nova",

		contlist_document_properties: "Propietats del document",
		contlist_folder_properties: "Propietats de la carpeta",
		contlist_folder_name: "Nom de carpeta",

		contlist_cancel_btn_label: "Cancel·la",
		contlist_add_btn_label: "Afegeix",
		contlist_ok_btn_label: "D'acord",
		contlist_edit_btn_label: "Edita",
		contlist_save_btn_label: "Desa",
		contlist_upload_btn_label: "Carrega",
		contlist_refresh_btn_label: "Renova",
		contlist_next_btn_label: "Següent",
		contlist_previous_btn_label: "Anterior",

		contlist_delete_folder_confirm: "Esteu a punt de suprimir la carpeta ${0}. Voleu continuar?",
		contlist_delete_doc_confirm: "Esteu a punt de suprimir el document ${0}. Voleu continuar?",

		contlist_no_mimetype: "Aquest element no té contingut.",
		contlist_folder_mimetype: "Carpeta",

		contlist_filter_search_hint: "Documents de cerca",
		contlist_filter_folder_hint: "Filtra la llista",

		contlist_root_folder: "Carpeta arrel",
		contlist_drop_folder_error: "No podeu afegir carpetes. Seleccioneu només fitxers. ",
		contlist_add_in_process: "Espereu fins que s'acabi d'afegir el document anterior abans d'afegir-ne un altre.",
		contlist_add_doc_max_exceeded: "Podeu afegir fins a ${0} elements alhora. Esteu intentant afegir ${1} elements.",
		contlist_progress_success: "Correcte",
		contlist_progress_alert: "Avís",
		contlist_progress_error: "Error",
		contlist_progress_uploading: "S'està carregant",
		contlist_progress_processing: "S'està processant 1 fitxer",
		contlist_progress_uploading_text: "S'està carregant 1 fitxer",
		contlist_progress_upload_failed: "S'ha produït un problema",
		contlist_progress_close: "Tanca",
		progress_ind_uploaded_status: "Carregat",
		progress_ind_uploaded: "S'ha carregat 1 fitxer",
		progress_ind_uploaded_error: "El processament no ha començat",		
		progress_ind_processing_status: "Processant",
		progress_ind_processing_err: "S'ha produït un problema",
		progress_ind_processed: "S'ha processat 1 fitxer",	
		progress_ind_failed: "Ha fallat",
		progress_ind_review_doc: "Revisió necessària",	
		progress_ind_updating: "S'està actualitzant 1 fitxer",
		progress_ind_updating_status: "Actualitzant",
		progress_ind_update_err: "S'ha produït un problema",
		progress_ind_timeout: "S'ha esgotat el temps d'espera de la supervisió",
		progress_ind_refresh: "Renova",

		getcontent_ret_versions_error: "Ha fallat la recuperació de sèries de versió",
		getcontent_ret_properties_error: "Ha fallat la recuperació de les propietats del document",

		contentviewer_test_mode: "El Visualitzador no mostrarà els documents en mode de visualització prèvia. Heu d'estar executant una aplicació d'escriptori de l'IBM Navigator.",

		thumbnail_retreival_error: "Ha fallat la recuperació de la imatge en miniatura.",

		status_10: "Carregat",
		status_20: "Processant",
		status_25: "Reprocessant",
		status_30: "Revisió necessària",
		status_40: "Actualitzant",
		status_900: "Error de processament",
		status_910: "Error d'actualització",

		/*do not remove this line*/nop: null
});
