/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Κλάση",

		// Property list
		properties_file_name: "Όνομα αρχείου",
		properties_file_save_in: "Αποθήκευση σε",
		properties_add_file: "Προσθήκη αρχείου",
		properties_add_mvcp: "Προσθήκη: ${0}",
		properties_remove_mvcp: "Αφαίρεση από: ${0}",
		properties_use_file_name: "Το όνομα αρχείου θα χρησιμοποιηθεί για αυτή την ιδιότητα",

		properties_optional_label: "${0} (προαιρετικό)",

		properties_document_or_folder_not_found: "Δεν είναι δυνατή η εύρεση του εγγράφου ή του φακέλου.",
		properties_class_not_found: "Η κλάση περιεχομένου δεν βρέθηκε.",
		properties_folder_duplicate_item_invalid_prop: "Υπάρχει ήδη ένα στοιχείο με το ίδιο όνομα στον φάκελο ή καταχωρήσατε μη έγκυρη τιμή ιδιότητας.",
		properties_item_invalid_prop: "Καταχωρήσατε μια μη έγκυρη τιμή για μία ή περισσότερες ιδιότητες.",

		properties_invalid_long_value: "Αυτή η τιμή δεν είναι έγκυρη. Η τιμή πρέπει να είναι ακέραιος αριθμός, για παράδειγμα, 5 ή 1349.",
		properties_invalid_float_value: "Η τιμή δεν είναι έγκυρη. Η τιμή πρέπει να είναι αριθμός κινητής υποδιαστολής, για παράδειγμα, 1.2 ή 365.",
		properties_min_value: "Ελάχιστη τιμή: ${0}",
		properties_max_value: "Μέγιστη τιμή: ${0}",
		properties_max_length: "Μέγιστο μήκος: ${0}",
		properties_invalid_guid: "Η τιμή δεν είναι έγκυρη. Η τιμή πρέπει να είναι ταυτότητα GUID (Globally Unique Identifier), για παράδειγμα, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Αυτή η τιμή είναι απαιτούμενη.",
		properties_unique_value_required: "Η τιμή αυτή πρέπει να είναι μοναδική.",
		properties_file_required: "Απαιτείται αρχείο.",
		properties_invalid_folder_name: "Ένα όνομα φακέλου δεν μπορεί να περιέχει τους ακόλουθους χαρακτήρες: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Αλλάζετε τις ιδιότητες του ακόλουθου εγγράφου<br>${0}<br><br>Θέλετε να αποθηκεύσετε τις αλλαγές σας;",
		properties_move_edit_confirm_no: "Όχι",
		properties_move_edit_confirm_yes: "Ναι",
		properties_move_edit_confirm_title: "Επιβεβαίωση",
		properties_edit_save_success: "Οι ιδιότητες αποθηκεύτηκαν",
		properties_edit_save_failure: "Οι ιδιότητες δεν αποθηκεύτηκαν",
		properties_no_item_selected: "Δεν έχει επιλεγεί στοιχείο.",

		// Content list
		contlist_column_spec_title: "Τίτλος",
		contlist_column_spec_name: "Όνομα",
		contlist_column_spec_version_label: "Εκδοχή",
		contlist_column_spec_modified_by: "Τροποποιήθηκε από",
		contlist_column_spec_mod_date: "Τελευταία τροποποίηση",
		contlist_column_spec_created_by: "Δημιουργός",
		contlist_column_spec_creation_date: "Δημιουργήθηκε",
		contlist_column_spec_mime_type: "Είδος εγγράφου",
		contlist_column_spec_size: "Μέγεθος",
		contlist_column_spec_thumbnail: "Μικρογραφία",

		contlist_paging_no_more_items: "Δεν υπάρχουν άλλα στοιχεία",
		contlist_paging_of_at_least_items: "${0} από τουλάχιστον ${1} στοιχεία",
		contlist_paging_of_items: "${0} από ${1} στοιχεία",
		contlist_paging_items: "Στοιχεία ${0}",
		contlist_paging_items_per_page: "Στοιχεία ανά σελίδα: ${0}",

		contlist_checked_out: "Ανάληψη ελέγχου",
		contlist_checked_out_by: "Ανάληψη ελέγχου από: ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Δεν ορίστηκε εξυπηρετητής.",
		contlist_invalid_server_error: "Ο εξυπηρετητής '{0}' δεν υπάρχει.",
		contlist_error_retrieving_doc_props: "Σφάλμα κατά την ανάκτηση ιδιοτήτων εγγράφου.",
		contlist_error_retrieving_folder_props: "Σφάλμα κατά την ανάκτηση ιδιοτήτων φακέλου.",
		contlist_checkout_failed: "Δεν ήταν δυνατή η ανάληψη ελέγχου του εγγράφου",
		contlist_cancel_checkout_failed: "Απέτυχε η ακύρωση ανάληψης ελέγχου",
		contlist_rename_folder_failed: "Δεν ήταν δυνατή η μετονομασία του φακέλου.",
		contlist_folder_name_not_unique: "Το όνομα του φακέλου πρέπει να είναι μοναδικό.",
		contlist_delete_object_failed: "Δεν ήταν δυνατή η διαγραφή του αντικειμένου.",
		contlist_display_properties_failed: "Δεν ήταν δυνατή η εμφάνιση των ιδιοτήτων. ${0}",
		contlist_save_props_failed: "Δεν ήταν δυνατή η αποθήκευση των ιδιοτήτων",
		contlist_upload_failed: "Δεν ήταν δυνατή η μεταφόρτωση της εκδοχής",
		contlist_add_folder_failed: "Δεν ήταν δυνατή η προσθήκη του φακέλου. ${0}",
		contlist_add_document_failed: "Δεν ήταν δυνατή η προσθήκη του εγγράφου. ${0}",
		contlist_search_failed: "Δεν ήταν δυνατή η ανάκτηση των αποτελεσμάτων αναζήτησης",
		contlist_folder_containees_failed: "Δεν ήταν δυνατή η ανάκτηση των περιεχομένων του φακέλου",
		contlist_delete_folder_referenced: "Δεν είναι δυνατή η διαγραφή του φακέλου καθώς περιέχει υποφακέλους.",
		contlist_docs_not_added: "Δεν ήταν δυνατή η προσθήκη των ακόλουθων εγγράφων: ${0}",

		contlist_checkout_success: "Έγινε ανάληψη ελέγχου του εγγράφου",
		contlist_delete_success: "Το αντικείμενο διαγράφηκε",
		contlist_rename_folder_success: "Ο φάκελος μετονομάστηκε",
		contlist_save_props_success: "Οι ιδιότητες αποθηκεύτηκαν",
		contlist_cancel_checkout_success: "Επιτυχία ανάληψης ελέγχου",
		contlist_upload_version_success: "Η εκδοχή μεταφορτώθηκε",
		contlist_add_folder_success: "Ο φάκελος προστέθηκε",
		contlist_add_doc_success: "Το έγγραφο προστέθηκε",
		contlist_add_docs_success: "Τα έγγραφα προστέθηκαν",

		contlist_menu_action_open: "Άνοιγμα",
		contlist_menu_action_rename: "Μετονομασία",
		contlist_menu_action_properties: "Ιδιότητες",
		contlist_menu_action_view: "Προβολή",
		contlist_menu_action_download: "Κατέβασμα",
		contlist_menu_action_checkout: "Ανάληψη ελέγχου",
		contlist_menu_action_edit_document: "Τροποποίηση εγγράφου",
		contlist_menu_action_cancel_checkout: "Ακύρωση ανάληψης ελέγχου",
		contlist_menu_action_delete_doc: "Διαγραφή εγγράφου",
		contlist_menu_action_rename_folder: "Μετονομασία φακέλου",
		contlist_menu_action_add_folder: "Προσθήκη φακέλου",
		contlist_menu_action_delete_folder: "Διαγραφή φακέλου",
		contlist_menu_action_add_doc: "Προσθήκη εγγράφου",
		contlist_menu_action_upload: "Μεταφόρτωση νέας εκδοχής",

		contlist_document_properties: "Ιδιότητες εγγράφου",
		contlist_folder_properties: "Ιδιότητες φακέλου",
		contlist_folder_name: "Όνομα φακέλου",

		contlist_cancel_btn_label: "Ακύρωση",
		contlist_add_btn_label: "Προσθήκη",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Τροποποίηση",
		contlist_save_btn_label: "Αποθήκευση",
		contlist_upload_btn_label: "Ανέβασμα",
		contlist_refresh_btn_label: "Ανανέωση",
		contlist_next_btn_label: "Επόμενο",
		contlist_previous_btn_label: "Προηγούμενο",

		contlist_delete_folder_confirm: "Πρόκειται να διαγράψετε τον φάκελο ${0}. Θέλετε να συνεχίσετε;",
		contlist_delete_doc_confirm: "Πρόκειται να διαγράψετε το έγγραφο ${0}. Θέλετε να συνεχίσετε;",

		contlist_no_mimetype: "Αυτό το στοιχείο δεν έχει περιεχόμενο.",
		contlist_folder_mimetype: "Φάκελος",

		contlist_filter_search_hint: "Αναζήτηση εγγράφων",
		contlist_filter_folder_hint: "Φιλτράρισμα λίστας",

		contlist_root_folder: "Κεντρικός φάκελος",
		contlist_drop_folder_error: "Δεν μπορείτε να προσθέσετε φακέλους. Επιλέξτε μόνο αρχεία.",
		contlist_add_in_process: "Περιμένετε μέχρι να ολοκληρωθεί η προσθήκη του προηγούμενου εγγράφου για να προσθέσετε το επόμενο.",
		contlist_add_doc_max_exceeded: "Μπορείτε να προσθέσετε έως ${0} στοιχεία ταυτόχρονα. Προσπαθείτε να προσθέσετε ${1} στοιχεία.",
		contlist_progress_success: "Επιτυχία",
		contlist_progress_alert: "Ειδοποίηση",
		contlist_progress_error: "Σφάλμα",
		contlist_progress_uploading: "Μεταφόρτωση",
		contlist_progress_processing: "Επεξεργασία 1 αρχείου",
		contlist_progress_uploading_text: "Μεταφόρτωση 1 αρχείου",
		contlist_progress_upload_failed: "Παρουσιάστηκε πρόβλημα",
		contlist_progress_close: "Κλείσιμο",
		progress_ind_uploaded_status: "Μεταφορτώθηκε",
		progress_ind_uploaded: "Μεταφορτώθηκε 1 αρχείο",
		progress_ind_uploaded_error: "Η επεξεργασία δεν ξεκίνησε",		
		progress_ind_processing_status: "Σε επεξεργασία",
		progress_ind_processing_err: "Παρουσιάστηκε πρόβλημα",
		progress_ind_processed: "Έγινε επεξεργασία 1 αρχείου",	
		progress_ind_failed: "Απέτυχε",
		progress_ind_review_doc: "Απαιτείται εξέταση",	
		progress_ind_updating: "Γίνεται ενημέρωση 1 αρχείου",
		progress_ind_updating_status: "Γίνεται ενημέρωση",
		progress_ind_update_err: "Παρουσιάστηκε πρόβλημα",
		progress_ind_timeout: "Λήξη προθεσμίας παρακολούθησης",
		progress_ind_refresh: "Ανανέωση",

		getcontent_ret_versions_error: "Η ανάκτηση της σειράς εκδοχών απέτυχε",
		getcontent_ret_properties_error: "Η ανάκτηση των ιδιοτήτων εγγράφου απέτυχε",

		contentviewer_test_mode: "Η λειτουργία προβολής δεν θα εμφανίσει έγγραφα σε κατάσταση λειτουργίας προεπισκόπησης. Πρέπει να χρησιμοποιείτε μια εφαρμογή για υπολογιστές γραφείου του IBM Navigator.",

		thumbnail_retreival_error: "Η ανάκτηση της εικόνας μικρογραφίας απέτυχε.",

		status_10: "Μεταφορτώθηκε",
		status_20: "Σε επεξεργασία",
		status_25: "Γίνεται επανάληψη επεξεργασίας",
		status_30: "Απαιτείται εξέταση",
		status_40: "Γίνεται ενημέρωση",
		status_900: "Σφάλμα επεξεργασίας",
		status_910: "Σφάλμα ενημέρωσης",

		/*do not remove this line*/nop: null
});
