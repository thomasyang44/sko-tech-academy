/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Osztály",

		// Property list
		properties_file_name: "Fájlnév",
		properties_file_save_in: "Mentés helye",
		properties_add_file: "Fájl hozzáadása",
		properties_add_mvcp: "${0} hozzáadása",
		properties_remove_mvcp: "Eltávolítás innen: ${0}",
		properties_use_file_name: "Ehhez a tulajdonsághoz a fájlnév kerül felhasználásra",

		properties_optional_label: "${0} (elhagyható)",

		properties_document_or_folder_not_found: "A dokumentum vagy mappa nem található.",
		properties_class_not_found: "A tartalomosztály nem található.",
		properties_folder_duplicate_item_invalid_prop: "Már létezik ilyen nevű elem a mappában vagy érvénytelen tulajdonság értéket adott meg.",
		properties_item_invalid_prop: "Legalább egy tulajdonsághoz érvénytelen értéket adott meg.",

		properties_invalid_long_value: "Ez az érték nem érvényes. Az értéknek egész számnak kell lennie, például 5 vagy 1349.",
		properties_invalid_float_value: "Az érték érvénytelen. Az értéknek lebegőpontos számnak kell lennie, például 1.2 vagy 365.",
		properties_min_value: "Minimális érték: ${0}",
		properties_max_value: "Maximális érték: ${0}",
		properties_max_length: "Maximális hossz: ${0}",
		properties_invalid_guid: "Az érték érvénytelen. Az értéknek Globálisan egyedi azonosítónak (GUID) kell lennie, például: {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Ez az érték kötelező.",
		properties_unique_value_required: "Egyedi értéknek kell lennie.",
		properties_file_required: "A fájlnevet meg kell adni.",
		properties_invalid_folder_name: "A mappanév nem tartalmazhatja a következő karaktereket: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "A következő dokumentum tulajdonságait módosítja<br>${0}<br><br>Menti a módosításokat?",
		properties_move_edit_confirm_no: "Nem",
		properties_move_edit_confirm_yes: "Igen",
		properties_move_edit_confirm_title: "Megerősítés",
		properties_edit_save_success: "Tulajdonságok elmentve",
		properties_edit_save_failure: "A tulajdonságok nem kerültek mentésre.",
		properties_no_item_selected: "Nincs kijelölt elem.",

		// Content list
		contlist_column_spec_title: "Cím",
		contlist_column_spec_name: "Név",
		contlist_column_spec_version_label: "Változat",
		contlist_column_spec_modified_by: "Módosította:",
		contlist_column_spec_mod_date: "Legutóbbi módosítás",
		contlist_column_spec_created_by: "Létrehozó",
		contlist_column_spec_creation_date: "Létrehozta",
		contlist_column_spec_mime_type: "Dokumentumtípus",
		contlist_column_spec_size: "Méret",
		contlist_column_spec_thumbnail: "Miniatűr",

		contlist_paging_no_more_items: "Nincs több elem",
		contlist_paging_of_at_least_items: "${0} / legalább ${1} elem",
		contlist_paging_of_items: "${0} / ${1} elem",
		contlist_paging_items: "Elemek: ${0}",
		contlist_paging_items_per_page: "Elemek oldalanként: ${0}",

		contlist_checked_out: "Kiiktatva",
		contlist_checked_out_by: "${0} által kiiktatva",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Nem lett kiszolgáló meghatározva.",
		contlist_invalid_server_error: "A(z) „{0}” kiszolgáló nem létezik.",
		contlist_error_retrieving_doc_props: "Hiba történt a dokumentumtulajdonságok lekérése során.",
		contlist_error_retrieving_folder_props: "Hiba történt a mappatulajdonságok lekérése során.",
		contlist_checkout_failed: "A dokumentum nem iktatható ki",
		contlist_cancel_checkout_failed: "A kiiktatás megszakítása nem sikerült",
		contlist_rename_folder_failed: "A mappa nem nevezhető át.",
		contlist_folder_name_not_unique: "A mappanévnek egyedinek kell lennie.",
		contlist_delete_object_failed: "Az objektum nem törölhető.",
		contlist_display_properties_failed: "A tulajdonságokat nem lehetett megjeleníteni. ${0}",
		contlist_save_props_failed: "A tulajdonságokat nem lehetett menteni",
		contlist_upload_failed: "A változat nem tölthető fel",
		contlist_add_folder_failed: "A mappa nem adható hozzá. ${0}",
		contlist_add_document_failed: "A dokumentum nem adható hozzá. ${0}",
		contlist_search_failed: "A találatok nem olvashatók be",
		contlist_folder_containees_failed: "A mappa tartalma nem olvasható be",
		contlist_delete_folder_referenced: "A mappa nem törölhető, mert almappákat tartalmaz.",
		contlist_docs_not_added: "A következő dokumentumok nem adhatók hozzá: ${0}. ",

		contlist_checkout_success: "Az dokumentum kiiktatásra került.",
		contlist_delete_success: "Az objektumot törölték",
		contlist_rename_folder_success: "A mappát átnevezték",
		contlist_save_props_success: "A tulajdonságok mentésre kerültek",
		contlist_cancel_checkout_success: "A kiiktatás megszakítása sikerült",
		contlist_upload_version_success: "A változat feltöltésre került",
		contlist_add_folder_success: "A mappa hozzáadásra került",
		contlist_add_doc_success: "A dokumentum hozzáadásra került",
		contlist_add_docs_success: "A dokumentumok hozzáadásra kerültek",

		contlist_menu_action_open: "Megnyitás",
		contlist_menu_action_rename: "Átnevezés",
		contlist_menu_action_properties: "Tulajdonságok",
		contlist_menu_action_view: "Megjelenítés",
		contlist_menu_action_download: "Letöltés",
		contlist_menu_action_checkout: "Kiiktatás",
		contlist_menu_action_edit_document: "Dokumentum szerkesztése",
		contlist_menu_action_cancel_checkout: "Kiiktatás megszakítása",
		contlist_menu_action_delete_doc: "Dokumentum törlése",
		contlist_menu_action_rename_folder: "Mappa átnevezése",
		contlist_menu_action_add_folder: "Mappa hozzáadása",
		contlist_menu_action_delete_folder: "Mappa törlése",
		contlist_menu_action_add_doc: "Dokumentum hozzáadása",
		contlist_menu_action_upload: "Új változat feltöltése",

		contlist_document_properties: "Dokumentum tulajdonságai",
		contlist_folder_properties: "Mappa tulajdonságai",
		contlist_folder_name: "Mappa neve",

		contlist_cancel_btn_label: "Mégse",
		contlist_add_btn_label: "Hozzáadás",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Szerkesztés",
		contlist_save_btn_label: "Mentés",
		contlist_upload_btn_label: "Feltöltés",
		contlist_refresh_btn_label: "Frissítés",
		contlist_next_btn_label: "Következő",
		contlist_previous_btn_label: "Előző",

		contlist_delete_folder_confirm: "A(z) ${0} mappa törlésére készül. Kívánja folytatni?",
		contlist_delete_doc_confirm: "A(z) ${0} dokumentum törlésére készül. Kívánja folytatni?",

		contlist_no_mimetype: "Ebben az elemben nem található tartalom.",
		contlist_folder_mimetype: "Mappa",

		contlist_filter_search_hint: "Dokumentumok keresése",
		contlist_filter_folder_hint: "Lista szűrése",

		contlist_root_folder: "Gyökérmappa",
		contlist_drop_folder_error: "Nem vehet fel mappákat. Csak fájlokat válasszon ki. ",
		contlist_add_in_process: "Várja meg az előző dokumentum hozzáadásának befejeződését, mielőtt hozzáadna egy másikat.",
		contlist_add_doc_max_exceeded: "Egyidejűleg legfeljebb ${0} elem adható hozzá. ${1} elem hozzáadását kísérelte meg.",
		contlist_progress_success: "Sikeres",
		contlist_progress_alert: "Riasztás",
		contlist_progress_error: "Hiba",
		contlist_progress_uploading: "Feltöltés",
		contlist_progress_processing: "1 fájl feldolgozása",
		contlist_progress_uploading_text: "1 fájl feltöltése",
		contlist_progress_upload_failed: "Probléma merült fel",
		contlist_progress_close: "Bezárás",
		progress_ind_uploaded_status: "Feltöltve",
		progress_ind_uploaded: "1 fájl feltöltve",
		progress_ind_uploaded_error: "A feldolgozás nem indult el",		
		progress_ind_processing_status: "Feldolgozás",
		progress_ind_processing_err: "Probléma merült fel",
		progress_ind_processed: "1 fájl feldolgozva",	
		progress_ind_failed: "Meghiúsult",
		progress_ind_review_doc: "Felülvizsgálat szükséges",	
		progress_ind_updating: "1 fájl frissítése",
		progress_ind_updating_status: "Frissítés",
		progress_ind_update_err: "Probléma merült fel",
		progress_ind_timeout: "A megfigyelés túllépte az időkorlátot",
		progress_ind_refresh: "Frissítés",

		getcontent_ret_versions_error: "A változatsorozat lekérése meghiúsult",
		getcontent_ret_properties_error: "A dokumentum tulajdonságainak lekérése meghiúsult",

		contentviewer_test_mode: "A Megjelenítő előkép üzemmódban nem jelenít meg dokumentumokat. IBM Navigator asztali alkalmazásban kell futtatnia.",

		thumbnail_retreival_error: "A miniatűr kép lekérése meghiúsult.",

		status_10: "Feltöltve",
		status_20: "Feldolgozás",
		status_25: "Újrafeldolgozás",
		status_30: "Felülvizsgálat szükséges",
		status_40: "Frissítés",
		status_900: "Feldolgozási hiba",
		status_910: "Frissítési hiba",

		/*do not remove this line*/nop: null
});
