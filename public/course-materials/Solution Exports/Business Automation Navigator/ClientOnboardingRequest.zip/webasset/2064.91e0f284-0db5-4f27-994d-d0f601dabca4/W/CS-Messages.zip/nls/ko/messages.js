/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "클래스",

		// Property list
		properties_file_name: "파일 이름",
		properties_file_save_in: "저장 위치",
		properties_add_file: "파일 추가",
		properties_add_mvcp: "${0} 추가",
		properties_remove_mvcp: "${0}에서 제거",
		properties_use_file_name: "파일 이름이 이 특성에 사용됩니다.",

		properties_optional_label: "${0}(선택사항)",

		properties_document_or_folder_not_found: "문서 또는 폴더를 찾을 수 없습니다.",
		properties_class_not_found: "컨텐츠 클래스를 찾을 수 없습니다.",
		properties_folder_duplicate_item_invalid_prop: "동일한 이름의 항목이 폴더에 이미 있거나 유효하지 않은 특성 값을 입력했습니다.",
		properties_item_invalid_prop: "하나 이상의 특성에 대해 유효하지 않은 값을 입력했습니다.",

		properties_invalid_long_value: "이 값은 유효하지 않습니다. 값은 정수여야 합니다(예: 5 또는 1349).",
		properties_invalid_float_value: "값이 유효하지 않습니다. 값은 부동 소수점 숫자여야 합니다(예: 1.2 또는 365).",
		properties_min_value: "최소값: ${0}",
		properties_max_value: "최대값: ${0}",
		properties_max_length: "최대 길이: ${0}",
		properties_invalid_guid: "값이 유효하지 않습니다. 값은 GUID(Globally Unique Identifier)여야 합니다(예: {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}).",
		properties_value_required: "이 값은 필수입니다.",
		properties_unique_value_required: "이 값은 고유해야 합니다.",
		properties_file_required: "파일이 필요합니다.",
		properties_invalid_folder_name: "폴더 이름에 \\ / : * ? \" < > | 문자를 사용할 수 없습니다.",

		properties_move_edit_confirm_msg: "다음 문서의 특성을 변경합니다.<br>${0}<br><br>변경사항을 저장하시겠습니까?",
		properties_move_edit_confirm_no: "아니오",
		properties_move_edit_confirm_yes: "예",
		properties_move_edit_confirm_title: "확인",
		properties_edit_save_success: "특성이 저장됨",
		properties_edit_save_failure: "특성이 저장되지 않음",
		properties_no_item_selected: "항목이 선택되지 않았습니다.",

		// Content list
		contlist_column_spec_title: "제목",
		contlist_column_spec_name: "이름",
		contlist_column_spec_version_label: "버전",
		contlist_column_spec_modified_by: "수정자",
		contlist_column_spec_mod_date: "마지막 수정 날짜",
		contlist_column_spec_created_by: "작성자",
		contlist_column_spec_creation_date: "작성 날짜",
		contlist_column_spec_mime_type: "문서 유형",
		contlist_column_spec_size: "크기",
		contlist_column_spec_thumbnail: "썸네일",

		contlist_paging_no_more_items: "추가 항목이 없음",
		contlist_paging_of_at_least_items: "최소 ${1}개 항목 중 ${0}",
		contlist_paging_of_items: "${1}개 항목 중 ${0}",
		contlist_paging_items: "항목 ${0}",
		contlist_paging_items_per_page: "페이지당 항목: ${0}",

		contlist_checked_out: "체크아웃됨",
		contlist_checked_out_by: "${0}님이 체크아웃함",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "서버가 지정되지 않았습니다.",
		contlist_invalid_server_error: "'{0}' 서버가 존재하지 않습니다.",
		contlist_error_retrieving_doc_props: "문서 특성을 검색하는 중에 오류가 발생했습니다.",
		contlist_error_retrieving_folder_props: "폴더 특성을 검색하는 중에 오류가 발생했습니다.",
		contlist_checkout_failed: "문서를 체크아웃할 수 없음",
		contlist_cancel_checkout_failed: "체크아웃 취소 실패",
		contlist_rename_folder_failed: "폴더 이름을 바꿀 수 없음",
		contlist_folder_name_not_unique: "폴더 이름은 고유해야 합니다.",
		contlist_delete_object_failed: "오브젝트를 삭제할 수 없습니다.",
		contlist_display_properties_failed: "특성을 표시할 수 없습니다. ${0}",
		contlist_save_props_failed: "특성을 저장할 수 없음",
		contlist_upload_failed: "버전을 업로드할 수 없음",
		contlist_add_folder_failed: "폴더를 추가할 수 없습니다. ${0}",
		contlist_add_document_failed: "문서를 추가할 수 없습니다. ${0}",
		contlist_search_failed: "검색 결과를 검색할 수 없음",
		contlist_folder_containees_failed: "폴더 컨텐츠를 검색할 수 없음",
		contlist_delete_folder_referenced: "하위 폴더가 포함되어 있으므로 폴더를 삭제할 수 없습니다.",
		contlist_docs_not_added: "다음 문서를 추가할 수 없음: ${0}. ",

		contlist_checkout_success: "문서가 체크아웃됨",
		contlist_delete_success: "오브젝트가 삭제됨",
		contlist_rename_folder_success: "폴더 이름을 바꿈",
		contlist_save_props_success: "특성이 저장됨",
		contlist_cancel_checkout_success: "체크아웃 취소 성공",
		contlist_upload_version_success: "버전이 업로드됨",
		contlist_add_folder_success: "폴더가 추가됨",
		contlist_add_doc_success: "문서가 추가됨",
		contlist_add_docs_success: "문서가 추가됨",

		contlist_menu_action_open: "열기",
		contlist_menu_action_rename: "이름 바꾸기",
		contlist_menu_action_properties: "특성",
		contlist_menu_action_view: "보기",
		contlist_menu_action_download: "다운로드",
		contlist_menu_action_checkout: "체크아웃",
		contlist_menu_action_edit_document: "문서 편집",
		contlist_menu_action_cancel_checkout: "체크아웃 취소",
		contlist_menu_action_delete_doc: "문서 삭제",
		contlist_menu_action_rename_folder: "폴더 이름 바꾸기",
		contlist_menu_action_add_folder: "폴더 추가",
		contlist_menu_action_delete_folder: "폴더 삭제",
		contlist_menu_action_add_doc: "문서 추가",
		contlist_menu_action_upload: "새 버전 업로드",

		contlist_document_properties: "문서 특성",
		contlist_folder_properties: "폴더 특성",
		contlist_folder_name: "폴더 이름",

		contlist_cancel_btn_label: "취소",
		contlist_add_btn_label: "추가",
		contlist_ok_btn_label: "확인",
		contlist_edit_btn_label: "편집",
		contlist_save_btn_label: "저장",
		contlist_upload_btn_label: "업로드",
		contlist_refresh_btn_label: "새로 고침",
		contlist_next_btn_label: "다음",
		contlist_previous_btn_label: "이전",

		contlist_delete_folder_confirm: "${0} 폴더를 삭제하려고 합니다. 계속하시겠습니까?",
		contlist_delete_doc_confirm: "${0} 문서를 삭제하려고 합니다. 계속하시겠습니까?",

		contlist_no_mimetype: "이 항목에 컨텐츠가 없습니다.",
		contlist_folder_mimetype: "폴더",

		contlist_filter_search_hint: "문서 검색",
		contlist_filter_folder_hint: "목록 필터",

		contlist_root_folder: "루트 폴더",
		contlist_drop_folder_error: "폴더를 추가할 수 없습니다. 파일만 선택하십시오.",
		contlist_add_in_process: "다른 문서를 추가하려면 우선 이전 문서 추가가 완료될 때까지 기다리십시오.",
		contlist_add_doc_max_exceeded: "한 번에 최대 ${0}개의 항목을 추가할 수 있습니다. ${1}개의 항목을 추가하려고 합니다.",
		contlist_progress_success: "성공",
		contlist_progress_alert: "경보",
		contlist_progress_error: "오류",
		contlist_progress_uploading: "업로드 중",
		contlist_progress_processing: "1개 파일 처리 중",
		contlist_progress_uploading_text: "1개 파일 업로드 중",
		contlist_progress_upload_failed: "문제점 발생",
		contlist_progress_close: "닫기",
		progress_ind_uploaded_status: "업로드됨",
		progress_ind_uploaded: "1개 파일이 업로드됨",
		progress_ind_uploaded_error: "처리가 시작되지 않음",		
		progress_ind_processing_status: "처리 중",
		progress_ind_processing_err: "문제점 발생",
		progress_ind_processed: "1개 파일을 처리함",	
		progress_ind_failed: "실패함",
		progress_ind_review_doc: "검토가 필요함",	
		progress_ind_updating: "1개 파일 업데이트 중",
		progress_ind_updating_status: "업데이트 중",
		progress_ind_update_err: "문제점 발생",
		progress_ind_timeout: "모니터링 제한시간 초과",
		progress_ind_refresh: "새로 고침",

		getcontent_ret_versions_error: "버전 시리즈 검색에 실패함",
		getcontent_ret_properties_error: "문서 특성 검색에 실패함",

		contentviewer_test_mode: "뷰어는 미리보기 모드에서 문서를 표시하지 않습니다. IBM Navigator 데스크탑 애플리케이션에서 실행 중이어야 합니다.",

		thumbnail_retreival_error: "썸네일 이미지 검색에 실패했습니다.",

		status_10: "업로드됨",
		status_20: "처리 중",
		status_25: "재처리 중",
		status_30: "검토가 필요함",
		status_40: "업데이트 중",
		status_900: "처리 오류",
		status_910: "업데이트 오류",

		/*do not remove this line*/nop: null
});
