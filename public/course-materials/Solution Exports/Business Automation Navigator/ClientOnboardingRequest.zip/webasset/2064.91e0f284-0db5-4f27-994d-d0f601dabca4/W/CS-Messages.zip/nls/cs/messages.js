/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Třída",

		// Property list
		properties_file_name: "Název souboru",
		properties_file_save_in: "Uložit do",
		properties_add_file: "Přidat soubor",
		properties_add_mvcp: "Přidat ${0}",
		properties_remove_mvcp: "Odebrat z ${0}",
		properties_use_file_name: "Pro tuto vlastnost bude použit název souboru.",

		properties_optional_label: "${0} (volitelné)",

		properties_document_or_folder_not_found: "Dokument nebo složka nebyly nalezeny.",
		properties_class_not_found: "Třída obsahu nebyla nalezena.",
		properties_folder_duplicate_item_invalid_prop: "Položka se stejným názvem již ve složce existuje nebo jste zadali neplatnou hodnotu vlastnosti.",
		properties_item_invalid_prop: "Pro jednu či více vlastností jste zadali neplatnou hodnotu.",

		properties_invalid_long_value: "Tato hodnota je neplatná. Musí se jednat o celé číslo, například 5 nebo 1349.",
		properties_invalid_float_value: "Hodnota není platná. Musí se jednat o číslo s pohyblivou řádovou čárkou, například 1,2 nebo 365.",
		properties_min_value: "Minimální hodnota: ${0}",
		properties_max_value: "Maximální hodnota: ${0}",
		properties_max_length: "Maximální délka: ${0}",
		properties_invalid_guid: "Hodnota není platná. Musí se jednat o identifikátor GUID, například {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Tato hodnota je povinná.",
		properties_unique_value_required: "Tato hodnota musí být jedinečná.",
		properties_file_required: "Je vyžadován soubor.",
		properties_invalid_folder_name: "Název složky nesmí obsahovat následující znaky: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Provádíte změny vlastností následujícího dokumentu:<br>${0}<br><br>Chcete změny uložit?",
		properties_move_edit_confirm_no: "Ne",
		properties_move_edit_confirm_yes: "Ano",
		properties_move_edit_confirm_title: "Potvrzení",
		properties_edit_save_success: "Vlastnosti byly uloženy.",
		properties_edit_save_failure: "Vlastnosti nebyly uloženy.",
		properties_no_item_selected: "Není vybrána žádná položka.",

		// Content list
		contlist_column_spec_title: "Název",
		contlist_column_spec_name: "Název",
		contlist_column_spec_version_label: "Verze",
		contlist_column_spec_modified_by: "Změnil",
		contlist_column_spec_mod_date: "Poslední změna",
		contlist_column_spec_created_by: "Vytvořil",
		contlist_column_spec_creation_date: "Vytvořeno",
		contlist_column_spec_mime_type: "Typ dokumentu",
		contlist_column_spec_size: "Velikost",
		contlist_column_spec_thumbnail: "Miniatura",

		contlist_paging_no_more_items: "K dispozici nejsou žádné další položky.",
		contlist_paging_of_at_least_items: "${0} z nejméně ${1} položek",
		contlist_paging_of_items: "${0} z ${1} položek",
		contlist_paging_items: "Položky: ${0}",
		contlist_paging_items_per_page: "Položek na stránku: ${0}",

		contlist_checked_out: "Zapůjčeno",
		contlist_checked_out_by: "Zapůjčeno uživatelem ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "kB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Nebyl určen server.",
		contlist_invalid_server_error: "Server {0} neexistuje.",
		contlist_error_retrieving_doc_props: "Při načítání vlastností dokumentu došlo k chybě.",
		contlist_error_retrieving_folder_props: "Chyba při načítání vlastností složky.",
		contlist_checkout_failed: "Dokument se nepodařilo zapůjčit.",
		contlist_cancel_checkout_failed: "Zrušení zapůjčení se nezdařilo.",
		contlist_rename_folder_failed: "Složku se nepodařilo přejmenovat.",
		contlist_folder_name_not_unique: "Název složky musí být jedinečný.",
		contlist_delete_object_failed: "Objekt se nepodařilo odstranit.",
		contlist_display_properties_failed: "Vlastnosti se nepodařilo zobrazit. ${0}",
		contlist_save_props_failed: "Vlastnosti se nepodařilo uložit.",
		contlist_upload_failed: "Verzi se nepodařilo odeslat.",
		contlist_add_folder_failed: "Složku se nepodařilo přidat. ${0}",
		contlist_add_document_failed: "Dokument se nepodařilo přidat. ${0}",
		contlist_search_failed: "Výsledky hledání se nepodařilo načíst.",
		contlist_folder_containees_failed: "Obsah složky se nepodařilo načíst.",
		contlist_delete_folder_referenced: "Složku nelze odstranit, protože obsahuje podsložky.",
		contlist_docs_not_added: "Následující dokumenty nebylo možné přidat: ${0}",

		contlist_checkout_success: "Dokument byl zapůjčen.",
		contlist_delete_success: "Objekt byl odstraněn.",
		contlist_rename_folder_success: "Složka byla přejmenována.",
		contlist_save_props_success: "Vlastnosti byly uloženy.",
		contlist_cancel_checkout_success: "Zapůjčení bylo úspěšně zrušeno.",
		contlist_upload_version_success: "Verze byla odeslána.",
		contlist_add_folder_success: "Složka byla přidána.",
		contlist_add_doc_success: "Dokument byl přidán.",
		contlist_add_docs_success: "Dokumenty byly přidány.",

		contlist_menu_action_open: "Otevřít",
		contlist_menu_action_rename: "Přejmenovat",
		contlist_menu_action_properties: "Vlastnosti",
		contlist_menu_action_view: "Zobrazit",
		contlist_menu_action_download: "Stáhnout",
		contlist_menu_action_checkout: "Zapůjčit",
		contlist_menu_action_edit_document: "Upravit dokument",
		contlist_menu_action_cancel_checkout: "Zrušit zapůjčení",
		contlist_menu_action_delete_doc: "Odstranit dokument",
		contlist_menu_action_rename_folder: "Přejmenovat složku",
		contlist_menu_action_add_folder: "Přidat složku",
		contlist_menu_action_delete_folder: "Odstranit složku",
		contlist_menu_action_add_doc: "Přidat dokument",
		contlist_menu_action_upload: "Odeslat novou verzi",

		contlist_document_properties: "Vlastnosti dokumentu",
		contlist_folder_properties: "Vlastnosti složky",
		contlist_folder_name: "Název složky",

		contlist_cancel_btn_label: "Storno",
		contlist_add_btn_label: "Přidat",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Upravit",
		contlist_save_btn_label: "Uložit",
		contlist_upload_btn_label: "Odesílat",
		contlist_refresh_btn_label: "Aktualizovat",
		contlist_next_btn_label: "Další",
		contlist_previous_btn_label: "Předchozí",

		contlist_delete_folder_confirm: "Chystáte se odstranit složku ${0}. Chcete pokračovat?",
		contlist_delete_doc_confirm: "Chystáte se odstranit dokument ${0}. Chcete pokračovat?",

		contlist_no_mimetype: "Tato položka nemá žádný obsah.",
		contlist_folder_mimetype: "Složka",

		contlist_filter_search_hint: "Hledat v dokumentech",
		contlist_filter_folder_hint: "Filtrovat seznam",

		contlist_root_folder: "Kořenová složka",
		contlist_drop_folder_error: "Složky nelze přidávat. Vyberte pouze soubory.",
		contlist_add_in_process: "Před přidáním dalšího dokumentu počkejte na dokončení přidání předchozího dokumentu.",
		contlist_add_doc_max_exceeded: "Najednou můžete přidat až ${0} položek. Pokoušíte se přidat ${1} položek.",
		contlist_progress_success: "Úspěch",
		contlist_progress_alert: "Výstraha",
		contlist_progress_error: "Chyba",
		contlist_progress_uploading: "Odesílání",
		contlist_progress_processing: "Zpracování 1 souboru",
		contlist_progress_uploading_text: "Odesílání 1 souboru",
		contlist_progress_upload_failed: "Došlo k problému",
		contlist_progress_close: "Zavřít",
		progress_ind_uploaded_status: " Odesláno",
		progress_ind_uploaded: "Odeslán 1 soubor",
		progress_ind_uploaded_error: "Zpracování se nezahájilo",		
		progress_ind_processing_status: "Zpracování",
		progress_ind_processing_err: "Došlo k problému",
		progress_ind_processed: "Zpracován 1 soubor",	
		progress_ind_failed: "Nezdařilo se",
		progress_ind_review_doc: "Vyžadováno přezkoumání",	
		progress_ind_updating: "Aktualizace 1 souboru",
		progress_ind_updating_status: "Aktualizace",
		progress_ind_update_err: "Došlo k problému",
		progress_ind_timeout: "Vypršel časový limit monitorování",
		progress_ind_refresh: "Aktualizovat",

		getcontent_ret_versions_error: "Načítání řady verzí se nezdařilo",
		getcontent_ret_properties_error: "Načítání vlastností dokumentu se nezdařilo",

		contentviewer_test_mode: "V režimu náhledu se v prohlížeči nezobrazují dokumenty. Musíte pracovat v desktopové aplikaci IBM Navigator.",

		thumbnail_retreival_error: "Načítání miniatury se nezdařilo.",

		status_10: "Odesláno",
		status_20: "Zpracování",
		status_25: "Opakované zpracování",
		status_30: "Vyžadováno přezkoumání",
		status_40: "Aktualizace",
		status_900: "Chyba zpracování",
		status_910: "Chyba aktualizace",

		/*do not remove this line*/nop: null
});
