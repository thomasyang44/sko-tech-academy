require({packages:[{name:"CS-Messages",location:com_ibm_bpm_coach.getManagedAssetUrl("CS-Messages.zip",com_ibm_bpm_coach.assetType_WEB,"SYSCST")}]});
