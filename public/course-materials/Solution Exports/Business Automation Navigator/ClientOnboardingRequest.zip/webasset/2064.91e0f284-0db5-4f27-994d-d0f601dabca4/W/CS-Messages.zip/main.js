/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */
 
 /**
 *	NOTE: This file and the other items in this directory must be compressed to a .zip file using an Ant script, for example like this:
 *
 *	<target name="DBAStudioZip">
 *		<delete dir="DBAStudioZip" />
 *		<zip destfile="DBAStudioZip/CS-Messages.zip">
 *			<fileset dir="DBAStudio" />
 *		</zip>
 *	</target>
 **/

define(["dojo/i18n!./nls/messages"], function(messages) {
	return messages;
});