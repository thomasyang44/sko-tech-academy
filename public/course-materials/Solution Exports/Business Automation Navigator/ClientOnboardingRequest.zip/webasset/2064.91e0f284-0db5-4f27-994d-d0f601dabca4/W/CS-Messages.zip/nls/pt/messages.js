/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Classe",

		// Property list
		properties_file_name: "Nome do ficheiro",
		properties_file_save_in: "Guardar em",
		properties_add_file: "Adicionar ficheiro",
		properties_add_mvcp: "Adicionar ${0}",
		properties_remove_mvcp: "Remover de ${0}",
		properties_use_file_name: "O nome do ficheiro será utilizado para esta propriedade",

		properties_optional_label: "${0} (opcional)",

		properties_document_or_folder_not_found: "Não é possível encontrar o documento ou a pasta.",
		properties_class_not_found: "Não é possível encontrar a classe de conteúdo.",
		properties_folder_duplicate_item_invalid_prop: "Já existe um item com o mesmo nome na pasta ou introduziu uma valor de propriedade inválido.",
		properties_item_invalid_prop: "Introduziu um valor inválido para uma ou mais propriedades.",

		properties_invalid_long_value: "Este valor não é válido. O valor tem de ser um número inteiro, por exemplo, 5 ou 1349.",
		properties_invalid_float_value: "O valor não é válido. O valor tem de ser um número de vírgula flutuante, por exemplo, 1,2 ou 365.",
		properties_min_value: "Valor mínimo: ${0}",
		properties_max_value: "Valor máximo: ${0}",
		properties_max_length: "Comprimento máximo: ${0}",
		properties_invalid_guid: "O valor não é válido. O valor tem de ser um identificador único global (GUID, Globally Unique Identifier), por exemplo, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Este valor é requerido.",
		properties_unique_value_required: "Esta valor tem de ser exclusivo.",
		properties_file_required: "É requerido um ficheiro.",
		properties_invalid_folder_name: "Um nome de pasta não pode incluir nenhum dos caracteres seguintes: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Está a alterar as propriedades do seguinte documento<br>${0}<br><br>Pretende guardar as suas alterações?",
		properties_move_edit_confirm_no: "Não",
		properties_move_edit_confirm_yes: "Sim",
		properties_move_edit_confirm_title: "Confirmação",
		properties_edit_save_success: "Propriedades guardadas",
		properties_edit_save_failure: "As propriedades não foram guardadas",
		properties_no_item_selected: "Nenhum item seleccionado.",

		// Content list
		contlist_column_spec_title: "Título",
		contlist_column_spec_name: "Nome",
		contlist_column_spec_version_label: "Versão",
		contlist_column_spec_modified_by: "Modificado por",
		contlist_column_spec_mod_date: "Última modificação",
		contlist_column_spec_created_by: "Criado por",
		contlist_column_spec_creation_date: "Criado",
		contlist_column_spec_mime_type: "Tipo de documento",
		contlist_column_spec_size: "Tamanho",
		contlist_column_spec_thumbnail: "Miniatura",

		contlist_paging_no_more_items: "Não existem mais itens",
		contlist_paging_of_at_least_items: "${0} de pelo menos ${1} itens",
		contlist_paging_of_items: "${0} de ${1} itens",
		contlist_paging_items: "Itens ${0}",
		contlist_paging_items_per_page: "Itens por página: ${0}",

		contlist_checked_out: "Com saída dada",
		contlist_checked_out_by: "Saída dada por ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Não foi especificado um servidor.",
		contlist_invalid_server_error: "o servidor '{0}' não existe.",
		contlist_error_retrieving_doc_props: "Erro na obtenção das propriedades do documento.",
		contlist_error_retrieving_folder_props: "Erro ao obter propriedades da pasta.",
		contlist_checkout_failed: "Não foi possível dar saída do documento",
		contlist_cancel_checkout_failed: "O cancelamento da saída falhou",
		contlist_rename_folder_failed: "Não foi possível mudar o nome da pasta.",
		contlist_folder_name_not_unique: "O nome da pasta tem de ser exclusivo.",
		contlist_delete_object_failed: "Não foi possível eliminar o objecto.",
		contlist_display_properties_failed: "Não foi possível apresentar as propriedades. ${0}",
		contlist_save_props_failed: "Não foi possível guardar as propriedades",
		contlist_upload_failed: "Não foi possível carregar a versão",
		contlist_add_folder_failed: "Não foi possível adicionar a pasta. ${0}",
		contlist_add_document_failed: "Não foi possível adicionar o documento. ${0}",
		contlist_search_failed: "Não foi possível obter os resultados da procura",
		contlist_folder_containees_failed: "Não foi possível obter os conteúdos da pasta",
		contlist_delete_folder_referenced: "Não é possível eliminar a pasta porque esta contém subpastas.",
		contlist_docs_not_added: "Não foi possível adicionar os seguintes documentos: ${0}",

		contlist_checkout_success: "Foi dada saída do documento",
		contlist_delete_success: "O objecto foi eliminado",
		contlist_rename_folder_success: "O nome da pasta foi mudado",
		contlist_save_props_success: "As propriedades foram guardadas",
		contlist_cancel_checkout_success: "O cancelamento da saída foi bem sucedido",
		contlist_upload_version_success: "A versão foi carregada",
		contlist_add_folder_success: "A pasta foi adicionada",
		contlist_add_doc_success: "O documento foi adicionado",
		contlist_add_docs_success: "Os documentos foram adicionados",

		contlist_menu_action_open: "Abrir",
		contlist_menu_action_rename: "Mudar o nome",
		contlist_menu_action_properties: "Propriedades",
		contlist_menu_action_view: "Ver",
		contlist_menu_action_download: "Descarregar",
		contlist_menu_action_checkout: "Dar saída",
		contlist_menu_action_edit_document: "Editar documento",
		contlist_menu_action_cancel_checkout: "Cancelar saída",
		contlist_menu_action_delete_doc: "Eliminar documento",
		contlist_menu_action_rename_folder: "Mudar o nome da pasta",
		contlist_menu_action_add_folder: "Adicionar pasta",
		contlist_menu_action_delete_folder: "Eliminar pasta",
		contlist_menu_action_add_doc: "Adicionar documento",
		contlist_menu_action_upload: "Carregar nova versão",

		contlist_document_properties: "Propriedades do documento",
		contlist_folder_properties: "Propriedades da pasta",
		contlist_folder_name: "Nome da pasta",

		contlist_cancel_btn_label: "Cancelar",
		contlist_add_btn_label: "Adicionar",
		contlist_ok_btn_label: "Ok",
		contlist_edit_btn_label: "Editar",
		contlist_save_btn_label: "Guardar",
		contlist_upload_btn_label: "Carregar",
		contlist_refresh_btn_label: "Actualizar",
		contlist_next_btn_label: "Seguinte",
		contlist_previous_btn_label: "Anterior",

		contlist_delete_folder_confirm: "Está prestes a eliminar a pasta ${0}. Pretende continuar?",
		contlist_delete_doc_confirm: "Está prestes a eliminar o documento ${0}. Pretende continuar?",

		contlist_no_mimetype: "Este item não inclui conteúdo.",
		contlist_folder_mimetype: "Pasta",

		contlist_filter_search_hint: "Procurar documentos",
		contlist_filter_folder_hint: "Filtrar lista",

		contlist_root_folder: "Pasta raiz",
		contlist_drop_folder_error: "Não pode adicionar pastas. Seleccione apenas ficheiros.",
		contlist_add_in_process: "Aguarde até que a adição do documento anterior seja concluída antes de adicionar outro documento.",
		contlist_add_doc_max_exceeded: "Pode adicionar até ${0} itens de cada vez. Está a tentar adicionar ${1} itens.",
		contlist_progress_success: "Êxito",
		contlist_progress_alert: "Alerta",
		contlist_progress_error: "Erro",
		contlist_progress_uploading: "A carregar",
		contlist_progress_processing: "A processar 1 ficheiro",
		contlist_progress_uploading_text: "A carregar 1 ficheiro",
		contlist_progress_upload_failed: "Ocorreu um problema",
		contlist_progress_close: "Fechar",
		progress_ind_uploaded_status: "Carregado",
		progress_ind_uploaded: "Um ficheiro carregado",
		progress_ind_uploaded_error: "O processamento não foi iniciado",		
		progress_ind_processing_status: "A processar",
		progress_ind_processing_err: "Ocorreu um problema",
		progress_ind_processed: "Um ficheiro processado",	
		progress_ind_failed: "Falha",
		progress_ind_review_doc: "Revisão requerida",	
		progress_ind_updating: "A actualizar 1 ficheiro",
		progress_ind_updating_status: "A actualizar",
		progress_ind_update_err: "Ocorreu um problema",
		progress_ind_timeout: "A monitorizar o tempo de espera",
		progress_ind_refresh: "Actualizar",

		getcontent_ret_versions_error: "A obtenção da série da versão falhou",
		getcontent_ret_properties_error: "A obtenção das propriedades do documento falhou",

		contentviewer_test_mode: "O Visualizador não apresentará documentos em modo de pré-visualização. Tem que estar a executar numa aplicação de ambiente de trabalho do IBM Navigator.",

		thumbnail_retreival_error: "A obtenção da imagem de miniatura falhou.",

		status_10: "Carregado",
		status_20: "A processar",
		status_25: "A processar de novo",
		status_30: "Revisão requerida",
		status_40: "A actualizar",
		status_900: "Erro de processamento",
		status_910: "Erro de actualização",

		/*do not remove this line*/nop: null
});
