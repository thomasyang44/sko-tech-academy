/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Lớp",

		// Property list
		properties_file_name: "Tên tập tin",
		properties_file_save_in: "Lưu trong",
		properties_add_file: "Thêm tập tin",
		properties_add_mvcp: "Thêm ${0}",
		properties_remove_mvcp: "Xóa khỏi ${0}",
		properties_use_file_name: "Tên tập tin sẽ được dùng cho thuộc tính này",

		properties_optional_label: "${0} (tùy chọn)",

		properties_document_or_folder_not_found: "Không thể tìm thấy tài liệu hoặc thư mục.",
		properties_class_not_found: "Không thể tìm thấy lớp nội dung.",
		properties_folder_duplicate_item_invalid_prop: "Mục có cùng tên đã tồn tại trong thư mục, hoặc bạn đã nhận giá trị thuộc tính không hợp lệ.",
		properties_item_invalid_prop: "Bạn đã nhập giá trị không hợp lệ cho một hoặc nhiều thuộc tính.",

		properties_invalid_long_value: "Giá trị này không hợp lệ. Giá trị phải là số nguyên, ví dụ 5 hoặc 1349.",
		properties_invalid_float_value: "Giá trị không hợp lệ. Giá trị phải là số có dấu chấm động, ví dụ 1.2 hoặc 365.",
		properties_min_value: "Giá trị tối thiểu: ${0}",
		properties_max_value: "Giá trị tối đa: ${0}",
		properties_max_length: "Ðộ dài tối đa: ${0}",
		properties_invalid_guid: "Giá trị không hợp lệ. Giá trị phải là một mã nhận dạng duy nhất toàn cầu (GUID), ví dụ, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Giá trị này được yêu cầu.",
		properties_unique_value_required: "Giá trị này phải là duy nhất.",
		properties_file_required: "Yêu cầu phải có tập tin.",
		properties_invalid_folder_name: "Tên thư mục không thể chứa bất kỳ ký tự nào sau đây: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Bạn đang thay đổi các thuộc tính của tài liệu sau<br>${0}<br><br>Bạn có muốn lưu các thay đổi không?",
		properties_move_edit_confirm_no: "Không",
		properties_move_edit_confirm_yes: "Có",
		properties_move_edit_confirm_title: "Xác nhận",
		properties_edit_save_success: "Các thuộc tính được lưu",
		properties_edit_save_failure: "Các thuộc tính không được lưu",
		properties_no_item_selected: "Không có mục chọn.",

		// Content list
		contlist_column_spec_title: "Tiêu đề",
		contlist_column_spec_name: "Tên",
		contlist_column_spec_version_label: "Phiên bản",
		contlist_column_spec_modified_by: "Ðược điều chỉnh bởi",
		contlist_column_spec_mod_date: "Ðược điều chỉnh lần cuối",
		contlist_column_spec_created_by: "Tạo bởi",
		contlist_column_spec_creation_date: "Ðược tạo",
		contlist_column_spec_mime_type: "Kiểu tài liệu",
		contlist_column_spec_size: "Kích thước",
		contlist_column_spec_thumbnail: "Hình thu nhỏ",

		contlist_paging_no_more_items: "Không có thêm mục",
		contlist_paging_of_at_least_items: "${0} của ít nhất ${1} mục",
		contlist_paging_of_items: "${0} của ${1} mục",
		contlist_paging_items: "Mục ${0}",
		contlist_paging_items_per_page: "Các mục mỗi trang: ${0}",

		contlist_checked_out: "Ðã kiểm xuất",
		contlist_checked_out_by: "Ðược kiểm xuất bởi ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Máy chủ không được xác định.",
		contlist_invalid_server_error: "Máy chủ '{0}' không tồn tại.",
		contlist_error_retrieving_doc_props: "Lỗi khi truy xuất thuộc tính tài liệu.",
		contlist_error_retrieving_folder_props: "Lỗi truy xuất thuộc tính thư mục.",
		contlist_checkout_failed: "Không thể kiểm xuất tài liệu",
		contlist_cancel_checkout_failed: "Hủy kiểm xuất không thành công",
		contlist_rename_folder_failed: "Không thể đổi tên thư mục.",
		contlist_folder_name_not_unique: "Tên thư mục phải là duy nhất.",
		contlist_delete_object_failed: "Không thể xóa đối tượng.",
		contlist_display_properties_failed: "Không thể hiển thị các thuộc tính. ${0}",
		contlist_save_props_failed: "Không thể lưu các thuộc tính",
		contlist_upload_failed: "Không thể tải phiên bản lên",
		contlist_add_folder_failed: "Không thể thêm thư mục. ${0}",
		contlist_add_document_failed: "Không thể thêm tài liệu. ${0}",
		contlist_search_failed: "Không thể truy xuất kết quả tìm kiếm",
		contlist_folder_containees_failed: "Không thể truy xuất nội dung thư mục",
		contlist_delete_folder_referenced: "Không thể xóa thư mục vì nó chứa các thư mục con.",
		contlist_docs_not_added: "Không thể thêm các tài liệu sau: ${0}",

		contlist_checkout_success: "Tài liệu được kiểm xuất",
		contlist_delete_success: "Ðối tượng bị xóa",
		contlist_rename_folder_success: "Thư mục được đổi tên",
		contlist_save_props_success: "Thuộc tính được lưu",
		contlist_cancel_checkout_success: "Hủy kiểm xuất thành công",
		contlist_upload_version_success: "Phiên bản được tải lên",
		contlist_add_folder_success: "Thư mục được thêm vào",
		contlist_add_doc_success: "Tài liệu được thêm vào",
		contlist_add_docs_success: "Tài liệu được thêm vào",

		contlist_menu_action_open: "Mở",
		contlist_menu_action_rename: "Ðặt lại tên",
		contlist_menu_action_properties: "Thuộc tính",
		contlist_menu_action_view: "Hiện",
		contlist_menu_action_download: "Tải xuống",
		contlist_menu_action_checkout: "Kiểm xuất",
		contlist_menu_action_edit_document: "Sửa tài liệu",
		contlist_menu_action_cancel_checkout: "Hủy kiểm xuất",
		contlist_menu_action_delete_doc: "Xóa tài liệu",
		contlist_menu_action_rename_folder: "Ðổi tên thư mục",
		contlist_menu_action_add_folder: "Thêm thư mục",
		contlist_menu_action_delete_folder: "Xóa thư mục",
		contlist_menu_action_add_doc: "Thêm tài liệu",
		contlist_menu_action_upload: "Tải lên phiên bản mới",

		contlist_document_properties: "Thuộc tính tài liệu",
		contlist_folder_properties: "Thuộc tính thư mục",
		contlist_folder_name: "Tên thư mục",

		contlist_cancel_btn_label: "Hủy",
		contlist_add_btn_label: "Thêm",
		contlist_ok_btn_label: "Ok",
		contlist_edit_btn_label: "Sửa",
		contlist_save_btn_label: "Lưu",
		contlist_upload_btn_label: "Tải lên",
		contlist_refresh_btn_label: "Làm mới",
		contlist_next_btn_label: "Kế tiếp",
		contlist_previous_btn_label: "Trước",

		contlist_delete_folder_confirm: "Bạn sắp phải xóa thư mục ${0}. Bạn có muốn tiếp tục không?",
		contlist_delete_doc_confirm: "Bạn sắp phải xóa tài liệu ${0}. Bạn có muốn tiếp tục không?",

		contlist_no_mimetype: "Mục này không chứa nội dung.",
		contlist_folder_mimetype: "Thư mục",

		contlist_filter_search_hint: "Tìm kiếm tài liệu",
		contlist_filter_folder_hint: "Danh sách bộ lọc",

		contlist_root_folder: "Thư mục gốc",
		contlist_drop_folder_error: "Bạn không thể thêm thư mục. Chỉ chọn tập tin.",
		contlist_add_in_process: "Vui lòng đợi cho đến khi việc thêm tài liệu trước đó hoàn tất trước khi thêm tài liệu khác.",
		contlist_add_doc_max_exceeded: "Có thể thêm đến ${0} mục trong một lần. Bạn đang cố thêm ${1} mục.",
		contlist_progress_success: "Thành công",
		contlist_progress_alert: "Cảnh báo",
		contlist_progress_error: "Lỗi",
		contlist_progress_uploading: "Ðang tải lên",
		contlist_progress_processing: "Ðang xử lý 1 tập tin",
		contlist_progress_uploading_text: "Ðang tải lên 1 tập tin",
		contlist_progress_upload_failed: "Ðã xảy ra sự cố",
		contlist_progress_close: "Ðóng",
		progress_ind_uploaded_status: "Ðã tải lên",
		progress_ind_uploaded: "Ðã tải lên 1 tập tin",
		progress_ind_uploaded_error: "Việc xử lý chưa bắt đầu",		
		progress_ind_processing_status: "Ðang xử lý",
		progress_ind_processing_err: "Ðã xảy ra sự cố",
		progress_ind_processed: "Ðã xử lý 1 tập tin",	
		progress_ind_failed: "Thất bại",
		progress_ind_review_doc: "Cần đánh giá",	
		progress_ind_updating: "Ðang cập nhật 1 tập tin",
		progress_ind_updating_status: "Ðang cập nhật",
		progress_ind_update_err: "Ðã xảy ra sự cố",
		progress_ind_timeout: "Việc giám sát đã hết giờ",
		progress_ind_refresh: "Làm mới",

		getcontent_ret_versions_error: "Truy xuất sê-ri phiên bản không thành công",
		getcontent_ret_properties_error: "Truy xuất thuộc tính tài liệu không thành công",

		contentviewer_test_mode: "Trình Xem sẽ không hiển thị tài liệu ở chế độ xem trước. Bạn phải chạy trong ứng dụng máy khách IBM Navigator.",

		thumbnail_retreival_error: "Truy xuất hình ảnh hình nhỏ không thành công.",

		status_10: "Ðã tải lên",
		status_20: "Ðang xử lý",
		status_25: "Ðang xử lý lại",
		status_30: "Yêu cầu đánh giá",
		status_40: "Ðang cập nhật",
		status_900: "Lỗi xử lý",
		status_910: "Lỗi cập nhật",

		/*do not remove this line*/nop: null
});
