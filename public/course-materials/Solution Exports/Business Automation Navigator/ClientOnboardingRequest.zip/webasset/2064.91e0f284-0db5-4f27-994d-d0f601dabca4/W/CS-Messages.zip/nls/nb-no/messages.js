/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Klasse",

		// Property list
		properties_file_name: "Filnavn",
		properties_file_save_in: "Lagre i",
		properties_add_file: "Legg til fil",
		properties_add_mvcp: "Legg til ${0}",
		properties_remove_mvcp: "Fjern fra ${0}",
		properties_use_file_name: "Filnavnet brukes for denne egenskapen",

		properties_optional_label: "${0} (valgfritt)",

		properties_document_or_folder_not_found: "Dokumentet eller mappen ble ikke funnet.",
		properties_class_not_found: "Innholdsklassen ble ikke funnet.",
		properties_folder_duplicate_item_invalid_prop: "Det finnes allerede et element med samme navn i mappen, eller du oppgav en ugyldig egenskapsverdi.",
		properties_item_invalid_prop: "Du oppgav en ugyldig verdi for en eller flere egenskaper.",

		properties_invalid_long_value: "Denne verdien er ikke gyldig. Verdien må være et heltall, for eksempel 5 eller 1349.",
		properties_invalid_float_value: "Verdien er ikke gyldig. Verdien må være et flytetall, for eksempel 1,2 eller 365.",
		properties_min_value: "Minimumsverdi: ${0}",
		properties_max_value: "Maksimumsverdi: ${0}",
		properties_max_length: "Maksimumslengde:: ${0}",
		properties_invalid_guid: "Verdien er ikke gyldig. Verdien må være en globalt unik identifikator (GUID), for eksempel {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Denne verdien er obligatorisk.",
		properties_unique_value_required: "Denne verdien må være unik.",
		properties_file_required: "Det kreves en fil.",
		properties_invalid_folder_name: "Et mappenavn kan ikke inneholde noen av følgende tegn: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Du er i ferd med å endre egenskapene for følgende dokument<br>${0}<br><br>Vil du lagre endringene?",
		properties_move_edit_confirm_no: "Nei",
		properties_move_edit_confirm_yes: "Ja",
		properties_move_edit_confirm_title: "Bekreftelse",
		properties_edit_save_success: "Egenskaper lagret",
		properties_edit_save_failure: "Egenskapene ble ikke lagret",
		properties_no_item_selected: "Ingen elementer er valgt.",

		// Content list
		contlist_column_spec_title: "Tittel",
		contlist_column_spec_name: "Navn",
		contlist_column_spec_version_label: "Versjon",
		contlist_column_spec_modified_by: "Endret av",
		contlist_column_spec_mod_date: "Sist endret",
		contlist_column_spec_created_by: "Opprettet av",
		contlist_column_spec_creation_date: "Opprettet",
		contlist_column_spec_mime_type: "Dokumenttype",
		contlist_column_spec_size: "Størrelse",
		contlist_column_spec_thumbnail: "Miniatyrbilde",

		contlist_paging_no_more_items: "Det er ingen flere elementer",
		contlist_paging_of_at_least_items: "${0} av minst ${1} elementer",
		contlist_paging_of_items: "${0} av ${1} elementer",
		contlist_paging_items: "Elementer ${0}",
		contlist_paging_items_per_page: "Elementer per side: ${0}",

		contlist_checked_out: "Sjekket ut",
		contlist_checked_out_by: "Sjekket ut av ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "kB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: " GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Det var ikke angitt noen server.",
		contlist_invalid_server_error: "Serveren '{0}' finnes ikke.",
		contlist_error_retrieving_doc_props: "Feil ved henting av dokumentegenskaper.",
		contlist_error_retrieving_folder_props: "Feil ved henting av mappeegenskaper.",
		contlist_checkout_failed: "Dokumentet kunne ikke sjekkes ut",
		contlist_cancel_checkout_failed: "Avbrytelse av utsjekking mislyktes",
		contlist_rename_folder_failed: "Kunne ikke endre navn på mappen.",
		contlist_folder_name_not_unique: "Mappenavnet må være unikt.",
		contlist_delete_object_failed: "Objektet kunne ikke slettes.",
		contlist_display_properties_failed: "Egenskapene kunne ikke vises. ${0}",
		contlist_save_props_failed: "Egenskapene kunne ikke lagres",
		contlist_upload_failed: "Versjonen kunne ikke lastes opp",
		contlist_add_folder_failed: "Mappen kunne ikke legges til. ${0}",
		contlist_add_document_failed: "Dokumentet kunne ikke legges til. ${0}",
		contlist_search_failed: "Søkeresultatene kunne ikke hentes",
		contlist_folder_containees_failed: "Mappeinnholdet kunne ikke hentes",
		contlist_delete_folder_referenced: "Mappen kan ikke slettes fordi den inneholder undermapper.",
		contlist_docs_not_added: "Følgende dokumenter kunne ikke legges til: ${0}",

		contlist_checkout_success: "Dokumentet ble sjekket ut",
		contlist_delete_success: "Objektet ble slettet",
		contlist_rename_folder_success: "Mappenavnet ble endret",
		contlist_save_props_success: "Egenskapene ble lagret",
		contlist_cancel_checkout_success: "Avbrytelse av utsjekking var vellykket",
		contlist_upload_version_success: "Versjonen ble lastet opp",
		contlist_add_folder_success: "Mappen ble lagt til",
		contlist_add_doc_success: "Dokumentet ble lagt til",
		contlist_add_docs_success: "Dokumentene ble lagt til",

		contlist_menu_action_open: "Åpne",
		contlist_menu_action_rename: "Endre navn",
		contlist_menu_action_properties: "Egenskaper",
		contlist_menu_action_view: "Vis",
		contlist_menu_action_download: "Last ned",
		contlist_menu_action_checkout: "Sjekk ut",
		contlist_menu_action_edit_document: "Rediger dokument",
		contlist_menu_action_cancel_checkout: "Avbryt utsjekking",
		contlist_menu_action_delete_doc: "Slett dokument",
		contlist_menu_action_rename_folder: "Endre navn på mappe",
		contlist_menu_action_add_folder: "Legg til mappe",
		contlist_menu_action_delete_folder: "Slett mappe",
		contlist_menu_action_add_doc: "Legg til dokument",
		contlist_menu_action_upload: "Last opp ny versjon",

		contlist_document_properties: "Dokumentegenskaper",
		contlist_folder_properties: "Mappeegenskaper",
		contlist_folder_name: "Mappenavn",

		contlist_cancel_btn_label: "Avbryt",
		contlist_add_btn_label: "Legg til",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Rediger",
		contlist_save_btn_label: "Lagre",
		contlist_upload_btn_label: "Last opp",
		contlist_refresh_btn_label: "Oppdater",
		contlist_next_btn_label: "Neste",
		contlist_previous_btn_label: "Forrige",

		contlist_delete_folder_confirm: "Du er i ferd med å slette mappen ${0}. Vil du fortsette?",
		contlist_delete_doc_confirm: "Du er i ferd med å slette dokumentet ${0}. Vil du fortsette?",

		contlist_no_mimetype: "Dette elementet inneholder ikke noe innhold.",
		contlist_folder_mimetype: "Mappe",

		contlist_filter_search_hint: "Søk etter dokumenter",
		contlist_filter_folder_hint: "Filtrer liste",

		contlist_root_folder: "Rotmappe",
		contlist_drop_folder_error: "Du kan ikke legge til mapper. Velg bare filer.",
		contlist_add_in_process: "Vent til det forrige dokumentet er lagt til, før du legger til et annet.",
		contlist_add_doc_max_exceeded: "Du kan legge til opptil ${0} elementer om gangen. Du prøver å legge til ${1} elementer.",
		contlist_progress_success: "Vellykket",
		contlist_progress_alert: "Varsel",
		contlist_progress_error: "Feil",
		contlist_progress_uploading: "Laster opp",
		contlist_progress_processing: "Behandler 1 fil",
		contlist_progress_uploading_text: "Laster opp 1 fil",
		contlist_progress_upload_failed: "Det oppstod et problem",
		contlist_progress_close: "Lukk",
		progress_ind_uploaded_status: "Opplastet",
		progress_ind_uploaded: "Lastet opp 1 fil",
		progress_ind_uploaded_error: "Behandlingen startet ikke",		
		progress_ind_processing_status: "Behandler",
		progress_ind_processing_err: "Det oppstod et problem",
		progress_ind_processed: "Behandlet 1 fil",	
		progress_ind_failed: "Mislykket",
		progress_ind_review_doc: "Gjennomgang kreves",	
		progress_ind_updating: "Oppdaterer 1 fil",
		progress_ind_updating_status: "Oppdaterer",
		progress_ind_update_err: "Det oppstod et problem",
		progress_ind_timeout: "Overvåking ble tidsavbrutt",
		progress_ind_refresh: "Oppdater",

		getcontent_ret_versions_error: "Henting av versjonsserie mislyktes",
		getcontent_ret_properties_error: "Henting av dokumentegenskaper mislyktes",

		contentviewer_test_mode: "Visningsprogrammet vil ikke vise dokumenter i forhåndsvisningsmodus. Du må bruke en IBM Navigator-skrivebordsapplikasjon.",

		thumbnail_retreival_error: "Henting av miniatyrbildet mislyktes.",

		status_10: "Opplastet",
		status_20: "Behandler",
		status_25: "Behandler på nytt",
		status_30: "Gjennomgang kreves",
		status_40: "Oppdaterer",
		status_900: "Behandlingsfeil",
		status_910: "Oppdateringsfeil",

		/*do not remove this line*/nop: null
});
