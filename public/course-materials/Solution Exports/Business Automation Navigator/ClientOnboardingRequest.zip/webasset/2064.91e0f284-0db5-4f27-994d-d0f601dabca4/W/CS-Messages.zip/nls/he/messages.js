/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "מחלקה",

		// Property list
		properties_file_name: "שם קובץ",
		properties_file_save_in: "שמירה בתוך",
		properties_add_file: "הוספת קובץ",
		properties_add_mvcp: "הוספת ${0}",
		properties_remove_mvcp: "סילוק מ-${0}",
		properties_use_file_name: "שם הקובץ ישמש עבור תכונה זו",

		properties_optional_label: "${0} (אופציונלי)",

		properties_document_or_folder_not_found: "המסמך או התיקיה לא נמצאו.",
		properties_class_not_found: "מחלקת התוכן לא נמצאה.",
		properties_folder_duplicate_item_invalid_prop: "פריט בשם זה כבר קיים בתיקיה, או שציינתם ערך תכונה לא חוקי.",
		properties_item_invalid_prop: "ציינתם ערך לא חוקי עבור תכונה אחת או יותר.",

		properties_invalid_long_value: "ערך זה אינו חוקי. הערך חייב להיות מספר שלם, לדוגמה, 5 או 1349.",
		properties_invalid_float_value: "הערך אינו חוקי. הערך חייב להיות מספר נקודה צפה, לדוגמה, 1.2 או 365.",
		properties_min_value: "ערך מינימלי: ${0}",
		properties_max_value: "ערך מרבי: ${0}",
		properties_max_length: "אורך מרבי: ${0}",
		properties_invalid_guid: "הערך אינו חוקי. הערך חייב להיות זיהוי GUID, לדוגמה, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "ערך זה דרוש.",
		properties_unique_value_required: "ערך זה חייב להיות ייחודי.",
		properties_file_required: "דרוש קובץ.",
		properties_invalid_folder_name: "שם תיקיה אינו יכול לכלול רווחים או תו כלשהו מהתווים האלה: * \\ / : ? \" < > |",

		properties_move_edit_confirm_msg: "שיניתם את התכונות של המסמך שלהלן<br>${0}<br><br>האם ברצונכם לשמור את השינויים?",
		properties_move_edit_confirm_no: "לא",
		properties_move_edit_confirm_yes: "כן",
		properties_move_edit_confirm_title: "אישור",
		properties_edit_save_success: "התכונות נשמרו",
		properties_edit_save_failure: "התכונות לא נשמרו",
		properties_no_item_selected: "לא נבחר פריט.",

		// Content list
		contlist_column_spec_title: "כותרת",
		contlist_column_spec_name: "שם",
		contlist_column_spec_version_label: "גירסה",
		contlist_column_spec_modified_by: "השתנה על-ידי",
		contlist_column_spec_mod_date: "שינוי אחרון",
		contlist_column_spec_created_by: "נוצר על ידי",
		contlist_column_spec_creation_date: "נוצר",
		contlist_column_spec_mime_type: "סוג מסמך",
		contlist_column_spec_size: "גודל",
		contlist_column_spec_thumbnail: "תמונה ממוזערת",

		contlist_paging_no_more_items: "אין עוד פריטים.",
		contlist_paging_of_at_least_items: "${0} מתוך לפחות ${1} פריטים",
		contlist_paging_of_items: "${0} מתוך ${1} פריטים",
		contlist_paging_items: "פריטים ${0}",
		contlist_paging_items_per_page: "פריטים בדף: ${0}",

		contlist_checked_out: "נמשך",
		contlist_checked_out_by: "נמשך על ידי ${0}.",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "לא צוין שרת.",
		contlist_invalid_server_error: "השרת '{0}' אינו קיים.",
		contlist_error_retrieving_doc_props: "שגיאה באחזור תכונות המסמך.",
		contlist_error_retrieving_folder_props: "שגיאה באחזור תכונות תיקיה.",
		contlist_checkout_failed: "לא ניתן למשוך את המסמך.",
		contlist_cancel_checkout_failed: "ביטול המשיכה נכשל",
		contlist_rename_folder_failed: "לא ניתן לשנות את שם התיקיה.",
		contlist_folder_name_not_unique: "שם התיקיה חייב להיות ייחודי.",
		contlist_delete_object_failed: "לא ניתן למחוק את האובייקט.",
		contlist_display_properties_failed: "לא ניתן להציג את התכונות. ${0}",
		contlist_save_props_failed: "לא ניתן לשמור את התכונות",
		contlist_upload_failed: "לא ניתן לטעון את הגרסה",
		contlist_add_folder_failed: "לא ניתן להוסיף את התיקיה. ${0}",
		contlist_add_document_failed: "לא ניתן להוסיף את המסמך. ${0}",
		contlist_search_failed: "לא ניתן לאחזר את תוצאות החיפוש",
		contlist_folder_containees_failed: "לא ניתן לאחזר את תוכן התיקיה",
		contlist_delete_folder_referenced: "לא ניתן למחוק את התיקיה מפני שהיא מכילה תת-תיקיות.",
		contlist_docs_not_added: "לא ניתן להוסיף את המסמכים שלהלן: ${0}",

		contlist_checkout_success: "המסמך נמשך.",
		contlist_delete_success: "האובייקט נמחק",
		contlist_rename_folder_success: "שם התיקיה שונה",
		contlist_save_props_success: "התכונות נשמרו",
		contlist_cancel_checkout_success: "ביטול המשיכה הצליח",
		contlist_upload_version_success: "הגרסה הועלתה",
		contlist_add_folder_success: "התיקיה נוספה",
		contlist_add_doc_success: "המסמך נוסף",
		contlist_add_docs_success: "המסמכים נוספו",

		contlist_menu_action_open: "פתיחה",
		contlist_menu_action_rename: "שינוי שם",
		contlist_menu_action_properties: "תכונות",
		contlist_menu_action_view: "הצגה",
		contlist_menu_action_download: "הורדה",
		contlist_menu_action_checkout: "משיכה",
		contlist_menu_action_edit_document: "עריכת מסמך",
		contlist_menu_action_cancel_checkout: "ביטול משיכה",
		contlist_menu_action_delete_doc: "מחיקת מסמך",
		contlist_menu_action_rename_folder: "שינוי שם תיקיה",
		contlist_menu_action_add_folder: "הוספת תיקיה",
		contlist_menu_action_delete_folder: "מחיקת תיקיה",
		contlist_menu_action_add_doc: "הוספת מסמך",
		contlist_menu_action_upload: "טעינת גרסה חדשה",

		contlist_document_properties: "תכונות מסמך",
		contlist_folder_properties: "תכונות תיקיה",
		contlist_folder_name: "שם תיקיה",

		contlist_cancel_btn_label: "ביטול",
		contlist_add_btn_label: "הוספה",
		contlist_ok_btn_label: "אישור",
		contlist_edit_btn_label: "עריכה",
		contlist_save_btn_label: "שמירה",
		contlist_upload_btn_label: "טעינה",
		contlist_refresh_btn_label: "רענון",
		contlist_next_btn_label: "הבא",
		contlist_previous_btn_label: "הקודם",

		contlist_delete_folder_confirm: "אתם עומדים למחוק את התיקיה ${0}. האם ברצונכם להמשיך?",
		contlist_delete_doc_confirm: "אתם עומדים למחוק את המסמך ${0}. האם ברצונכם להמשיך?",

		contlist_no_mimetype: "הפריט אינו מכיל תוכן.",
		contlist_folder_mimetype: "תיקיה",

		contlist_filter_search_hint: "חיפוש מסמכים",
		contlist_filter_folder_hint: "סינון רשימה",

		contlist_root_folder: "תיקיית יסוד",
		contlist_drop_folder_error: "אינכם יכולים להוסיף תיקיות. בחרו רק קבצים.",
		contlist_add_in_process: "נא להמתין עד שתושלם הוספת המסמך הקודם לפני הוספת מסמך נוסף",
		contlist_add_doc_max_exceeded: "תוכלו להוסיף עד ${0} פריטים בכל פעם. אתם מנסים להוסיף ${1} פריטים.",
		contlist_progress_success: "הצלחה",
		contlist_progress_alert: "התרעה",
		contlist_progress_error: "שגיאה",
		contlist_progress_uploading: "טוען",
		contlist_progress_processing: "מעבד קובץ 1",
		contlist_progress_uploading_text: "טוען קובץ 1",
		contlist_progress_upload_failed: "אירעה בעיה",
		contlist_progress_close: "סגירה",
		progress_ind_uploaded_status: "נטען",
		progress_ind_uploaded: "נטען קובץ 1",
		progress_ind_uploaded_error: "העיבוד לא התחיל",		
		progress_ind_processing_status: "עיבוד",
		progress_ind_processing_err: "אירעה בעיה",
		progress_ind_processed: "עובד קובץ 1",	
		progress_ind_failed: "נכשל",
		progress_ind_review_doc: "דרושה סקירה",	
		progress_ind_updating: "מעדכן קובץ 1",
		progress_ind_updating_status: "מעדכן",
		progress_ind_update_err: "אירעה בעיה",
		progress_ind_timeout: "הניטור חרג ממגבלת הזמן",
		progress_ind_refresh: "רענון",

		getcontent_ret_versions_error: "אחזור סדרת הגרסאות נכשל",
		getcontent_ret_properties_error: "אחזור תכונות המסמך נכשל",

		contentviewer_test_mode: "המציג לא יציג מסמכים במצב תצוגה מקדימה. יש להפעיל את יישום שולחן העבודה של IBM Navigator.",

		thumbnail_retreival_error: "אחזור התמונה הממוזערת נכשל.",

		status_10: "נטען",
		status_20: "עיבוד",
		status_25: "מעבד מחדש",
		status_30: "דרושה סקירה",
		status_40: "מעדכן",
		status_900: "שגיאת עיבוד",
		status_910: "שגיאת עדכון",

		/*do not remove this line*/nop: null
});
